import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  // Paystack Helper: Lazy Key Check & Fetch Proxy
  const getPaystackSecretKey = () => process.env.PAYSTACK_SECRET_KEY || '';

  // 1. Paystack Health & Configuration Status API
  app.get('/api/paystack/status', (req, res) => {
    const key = getPaystackSecretKey();
    res.json({
      configured: Boolean(key),
      publicKey: process.env.VITE_PAYSTACK_PUBLIC_KEY || 'pk_test_demo_mode',
      mode: key ? 'live_gateway' : 'sandbox_test_mode',
      message: key 
        ? 'Paystack Secret Key is active.' 
        : 'Running in sandbox mode with fallback test payment simulation. Set PAYSTACK_SECRET_KEY in environment variables for live processing.'
    });
  });

  // 2. Paystack Initialize Transaction (Deposit / Escrow Funding)
  app.post('/api/paystack/initialize', async (req, res) => {
    try {
      const { email, amount, callback_url, metadata } = req.body;
      const secretKey = getPaystackSecretKey();

      if (!secretKey) {
        // High quality sandbox simulation fallback
        const mockRef = `PSTK_SBX_${Math.random().toString(36).substring(2, 9).toUpperCase()}_${Date.now()}`;
        return res.json({
          status: true,
          message: 'Authorization URL created (Sandbox mode)',
          data: {
            authorization_url: `https://checkout.paystack.com/sandbox-demo-${mockRef}`,
            access_code: `acc_${mockRef}`,
            reference: mockRef
          }
        });
      }

      // Live Paystack API Request
      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email,
          amount: Math.round(Number(amount) * 100), // convert Naira to Kobo
          callback_url: callback_url || process.env.APP_URL,
          metadata
        })
      });

      const data = await response.json();
      return res.status(response.status).json(data);
    } catch (err: any) {
      console.error('Paystack Initialize Error:', err);
      return res.status(500).json({ status: false, message: err.message || 'Internal server error' });
    }
  });

  // 3. Paystack Verify Transaction
  app.get('/api/paystack/verify/:reference', async (req, res) => {
    try {
      const { reference } = req.params;
      const secretKey = getPaystackSecretKey();

      if (!secretKey || reference.startsWith('PSTK_SBX_')) {
        return res.json({
          status: true,
          message: 'Verification successful (Sandbox mode)',
          data: {
            amount: 500000,
            currency: 'NGN',
            transaction_date: new Date().toISOString(),
            status: 'success',
            reference,
            domain: 'test',
            gateway_response: 'Successful',
            channel: 'card'
          }
        });
      }

      const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
        headers: {
          Authorization: `Bearer ${secretKey}`
        }
      });

      const data = await response.json();
      return res.status(response.status).json(data);
    } catch (err: any) {
      console.error('Paystack Verify Error:', err);
      return res.status(500).json({ status: false, message: err.message || 'Internal server error' });
    }
  });

  // 4. Paystack Fetch Nigerian Banks List
  app.get('/api/paystack/banks', async (req, res) => {
    try {
      const secretKey = getPaystackSecretKey();

      if (!secretKey) {
        // Standard list of top Nigerian Banks
        return res.json({
          status: true,
          message: 'Banks retrieved (Default list)',
          data: [
            { name: 'Access Bank', code: '044', id: 1 },
            { name: 'Guaranty Trust Bank (GTBank)', code: '058', id: 2 },
            { name: 'United Bank For Africa (UBA)', code: '033', id: 3 },
            { name: 'Zenith Bank', code: '057', id: 4 },
            { name: 'First Bank of Nigeria', code: '011', id: 5 },
            { name: 'Kuda Microfinance Bank', code: '50211', id: 6 },
            { name: 'OPay', code: '999992', id: 7 },
            { name: 'Palmpay', code: '999991', id: 8 },
            { name: 'Moniepoint Microfinance Bank', code: '50515', id: 9 },
            { name: 'Wema Bank', code: '035', id: 10 }
          ]
        });
      }

      const response = await fetch('https://api.paystack.co/bank?country=nigeria', {
        headers: { Authorization: `Bearer ${secretKey}` }
      });

      const data = await response.json();
      return res.status(response.status).json(data);
    } catch (err: any) {
      return res.status(500).json({ status: false, message: err.message || 'Failed to fetch banks' });
    }
  });

  // 5. Paystack Resolve Account Number
  app.post('/api/paystack/resolve-account', async (req, res) => {
    try {
      const { accountNumber, bankCode } = req.body;
      const secretKey = getPaystackSecretKey();

      if (!secretKey) {
        return res.json({
          status: true,
          message: 'Account resolved (Sandbox mode)',
          data: {
            account_number: accountNumber,
            account_name: 'JOHN DEE (VERIFIED TEST PROVIDER)',
            bank_id: 1
          }
        });
      }

      const response = await fetch(
        `https://api.paystack.co/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`,
        {
          headers: { Authorization: `Bearer ${secretKey}` }
        }
      );

      const data = await response.json();
      return res.status(response.status).json(data);
    } catch (err: any) {
      return res.status(500).json({ status: false, message: err.message || 'Failed to resolve account' });
    }
  });

  // 6. Paystack Initiate Transfer (Withdrawal to Provider Bank)
  app.post('/api/paystack/transfer', async (req, res) => {
    try {
      const { amount, accountNumber, bankCode, accountName } = req.body;
      const secretKey = getPaystackSecretKey();

      if (!secretKey) {
        const mockTransferCode = `TRF_${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
        return res.json({
          status: true,
          message: 'Transfer queued successfully (Sandbox mode)',
          data: {
            reference: mockTransferCode,
            amount: amount * 100,
            status: 'success',
            recipient: accountName
          }
        });
      }

      // 1. Create Recipient
      const recipientRes = await fetch('https://api.paystack.co/transferrecipient', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          type: 'nuban',
          name: accountName,
          account_number: accountNumber,
          bank_code: bankCode,
          currency: 'NGN'
        })
      });
      const recipientData = await recipientRes.json();

      if (!recipientData.status) {
        return res.status(400).json(recipientData);
      }

      // 2. Initiate Transfer
      const transferRes = await fetch('https://api.paystack.co/transfer', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          source: 'balance',
          amount: Math.round(Number(amount) * 100),
          recipient: recipientData.data.recipient_code,
          reason: 'Tobjosh Escrow Payout'
        })
      });

      const transferData = await transferRes.json();
      return res.status(transferRes.status).json(transferData);
    } catch (err: any) {
      return res.status(500).json({ status: false, message: err.message || 'Transfer failed' });
    }
  });

  // 7. Paystack Webhook Handler
  app.post('/api/paystack/webhook', (req, res) => {
    const event = req.body;
    console.log('Paystack Webhook Received:', event?.event);
    res.sendStatus(200);
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
