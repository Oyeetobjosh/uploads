import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, OAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Config parsed from firebase-applet-config.json
const firebaseConfig = {
  apiKey: "AIzaSyB_2zn7IhQgfXwXa3rOdFlaeNGubegEGV4",
  authDomain: "gen-lang-client-0464918594.firebaseapp.com",
  projectId: "gen-lang-client-0464918594",
  storageBucket: "gen-lang-client-0464918594.firebasestorage.app",
  messagingSenderId: "631994400030",
  appId: "1:631994400030:web:0cade1fdcbf3730a6f5d0f"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);

// Initialize Firestore with the custom databaseId provided in config
export const db = getFirestore(app, "ai-studio-tobjoshultimates-c5ffe428-e2ff-42b8-95c4-8b3f6d3ffe25");

export const googleProvider = new GoogleAuthProvider();
export const appleProvider = new OAuthProvider("apple.com");
