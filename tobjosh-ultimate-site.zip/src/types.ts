/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AccountType = 'employer' | 'provider';

export interface UserProfile {
  username: string;
  email: string;
  fullName: string;
  avatar: string; // Base64 or avatar preset key
  accountType: AccountType;
  bio: string;
  skills: string[];
  balance: number;
  escrowBalance: number;
  location: {
    country: string;
    state: string;
    city: string;
  };
  isKycVerified?: boolean;
  kycType?: 'NIN' | 'BVN' | 'Student ID';
  kycNumber?: string;
  isStudentStartup?: boolean;
  startupName?: string;
  paystackAccount?: string;
  bankDetails?: {
    bankName: string;
    accountNumber: string;
    accountName: string;
  };
  rating?: number;
  completedGigsCount?: number;
}

export interface Job {
  id: string;
  title: string;
  description: string;
  type: 'gig' | 'errand'; // gig = physical event (pianist, catering), errand = online tasks
  category: string;
  budget: number;
  location: {
    country: string;
    state: string;
    city: string;
  };
  postedBy: string; // Username of employer
  hiredProvider: string | null; // Username of hired provider
  status: 'open' | 'escrow' | 'completed';
  createdAt: string;
  isStudentStartup?: boolean;
  urgency?: 'low' | 'medium' | 'high' | 'urgent';
  milestones?: { id: string; title: string; amount: number; completed: boolean }[];
  applicantsCount?: number;
  requiredKyc?: boolean;
}

export interface Transaction {
  id: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'escrow_hold' | 'escrow_release' | 'payment_received';
  description: string;
  date: string;
  paystackRef?: string;
  channel?: 'paystack_card' | 'paystack_transfer' | 'paystack_ussd' | 'paystack_student_free' | 'escrow_release' | 'bank_payout';
}

export interface LocationData {
  country: string;
  states: {
    name: string;
    cities: string[];
  }[];
}
