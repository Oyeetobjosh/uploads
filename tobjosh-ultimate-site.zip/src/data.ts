/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LocationData, Job, UserProfile } from './types';

export const WORLD_LOCATIONS: LocationData[] = [
  {
    country: "Nigeria",
    states: [
      { name: "Abuja (FCT)", cities: ["Maitama", "Wuse", "Garki", "Asokoro", "Gwarinpa", "Kubwa", "Lugbe"] },
      { name: "Abia", cities: ["Umuahia", "Aba", "Ohafia", "Arochukwu"] },
      { name: "Adamawa", cities: ["Yola", "Mubi", "Numan", "Jimeta"] },
      { name: "Akwa Ibom", cities: ["Uyo", "Eket", "Ikot Ekpene", "Oron"] },
      { name: "Anambra", cities: ["Awka", "Onitsha", "Nnewi", "Ekwulobia"] },
      { name: "Bauchi", cities: ["Bauchi", "Azare", "Misau", "Jama'are"] },
      { name: "Bayelsa", cities: ["Yenagoa", "Ogbia", "Brass", "Sagbama"] },
      { name: "Benue", cities: ["Makurdi", "Gboko", "Otukpo", "Katsina-Ala"] },
      { name: "Borno", cities: ["Maiduguri", "Biu", "Bama"] },
      { name: "Cross River", cities: ["Calabar", "Ikom", "Ogoja", "Ugep"] },
      { name: "Delta", cities: ["Asaba", "Warri", "Ughelli", "Sapele", "Agbor"] },
      { name: "Ebonyi", cities: ["Abakaliki", "Afikpo", "Onueke"] },
      { name: "Edo", cities: ["Benin City", "Auchi", "Ekpoma", "Uromi"] },
      { name: "Ekiti", cities: ["Ado-Ekiti", "Ikere", "Ikole", "Ijero"] },
      { name: "Enugu", cities: ["Enugu", "Nsukka", "Udi", "Oji River"] },
      { name: "Gombe", cities: ["Gombe", "Kaltungo", "Dukku"] },
      { name: "Imo", cities: ["Owerri", "Orlu", "Okigwe", "Mbaise"] },
      { name: "Jigawa", cities: ["Dutse", "Hadejia", "Birnin Kudu"] },
      { name: "Kaduna", cities: ["Kaduna", "Zaria", "Kafanchan", "Saminaka"] },
      { name: "Kano", cities: ["Kano Municipal", "Nassarawa", "Dala", "Fagge", "Tarauni"] },
      { name: "Katsina", cities: ["Katsina", "Daura", "Funtua"] },
      { name: "Kebbi", cities: ["Birnin Kebbi", "Argungu", "Yauri"] },
      { name: "Kogi", cities: ["Lokoja", "Okene", "Kabba", "Idah"] },
      { name: "Kwara", cities: ["Ilorin", "Offa", "Omu-Aran", "Jebba"] },
      { name: "Lagos", cities: ["Ikeja", "Lekki", "Victoria Island", "Yaba", "Surulere", "Ajah", "Ikorodu", "Epe", "Festac"] },
      { name: "Nasarawa", cities: ["Lafia", "Keffi", "Karu", "Akwanga"] },
      { name: "Niger", cities: ["Minna", "Bida", "Suleja", "Kontagora"] },
      { name: "Ogun", cities: ["Abeokuta", "Ijebu Ode", "Sagamu", "Ota", "Ilaro"] },
      { name: "Ondo", cities: ["Akure", "Ondo Town", "Owo", "Ikare"] },
      { name: "Osun", cities: ["Osogbo", "Ile-Ife", "Ilesa", "Ede"] },
      { name: "Oyo", cities: ["Ibadan Central", "Bodija", "Ogbomoso", "Oyo Town", "Iseyin"] },
      { name: "Plateau", cities: ["Jos", "Bukuru", "Pankshin"] },
      { name: "Rivers", cities: ["Port Harcourt", "Obio-Akpor", "Bonny", "Eleme", "Oyigbo"] },
      { name: "Sokoto", cities: ["Sokoto", "Tambuwal", "Wamako"] },
      { name: "Taraba", cities: ["Jalingo", "Wukari", "Bali"] },
      { name: "Yobe", cities: ["Damaturu", "Gashua", "Potiskum"] },
      { name: "Zamfara", cities: ["Gusau", "Kaura Namoda", "Talata Mafara"] }
    ]
  },
  {
    country: "United States",
    states: [
      { name: "California", cities: ["Los Angeles", "San Francisco", "San Diego", "San Jose"] },
      { name: "New York", cities: ["New York City", "Buffalo", "Albany"] },
      { name: "Texas", cities: ["Houston", "Austin", "Dallas"] }
    ]
  },
  {
    country: "United Kingdom",
    states: [
      { name: "England", cities: ["London", "Manchester", "Birmingham"] },
      { name: "Scotland", cities: ["Edinburgh", "Glasgow"] }
    ]
  }
];

export const DEFAULT_JOBS: Job[] = [
  // Nigerian Gigs
  {
    id: "gig-1",
    title: "Lead Pianist for Sunday Worship & Wedding Ceremony",
    description: "Looking for an experienced professional pianist to perform at a luxury wedding reception in Victoria Island. Rehearsal required before the event.",
    type: "gig",
    category: "Pianist",
    budget: 85000,
    location: {
      country: "Nigeria",
      state: "Lagos",
      city: "Victoria Island"
    },
    postedBy: "wedding_planner_pro",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-20T10:00:00Z"
  },
  {
    id: "gig-2",
    title: "Executive Catering Team for 100 Guests Gala",
    description: "Need a high-class Nigerian catering service to prepare Jollof rice, fried rice, pounded yam with egusi soup, and dessert platters for a corporate gala.",
    type: "gig",
    category: "Catering",
    budget: 450000,
    location: {
      country: "Nigeria",
      state: "Abuja (FCT)",
      city: "Maitama"
    },
    postedBy: "tobjosh_events",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-22T18:30:00Z"
  },
  {
    id: "gig-3",
    title: "Live Sound Engineer & Acoustic Tuning",
    description: "Urgent need for an audio sound engineer to configure and mix line array speakers for an outdoor concert at Polo Club.",
    type: "gig",
    category: "Sound Engineer",
    budget: 120000,
    location: {
      country: "Nigeria",
      state: "Rivers",
      city: "Port Harcourt"
    },
    postedBy: "austin_sounds",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-24T09:15:00Z"
  },
  {
    id: "gig-4",
    title: "Professional Event Photographer & Videographer",
    description: "Full-day photo and 4K video coverage for a birthday banquet. Raw footage + edited highlight reel required within 48 hours.",
    type: "gig",
    category: "Photography",
    budget: 150000,
    location: {
      country: "Nigeria",
      state: "Oyo",
      city: "Ibadan Central"
    },
    postedBy: "startup_founder",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-25T14:00:00Z"
  },
  // Errands
  {
    id: "errand-1",
    title: "React/TypeScript & Paystack Integration Tutor",
    description: "Looking for a 1-on-1 virtual tutor to teach advanced state management, clean architecture, and Paystack webhook implementation. 2-hour virtual session.",
    type: "errand",
    category: "Tutorials",
    budget: 35000,
    location: {
      country: "Nigeria",
      state: "Lagos",
      city: "Yaba"
    },
    postedBy: "learner_dan",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-21T11:45:00Z"
  },
  {
    id: "errand-2",
    title: "Document & Grocery Campus Express Delivery",
    description: "Urgent errand runner to pick up official transcripts from UNILAG Akoka campus and deliver to Lekki Phase 1 before 4 PM today.",
    type: "errand",
    category: "Errand Runner",
    budget: 15000,
    location: {
      country: "Nigeria",
      state: "Lagos",
      city: "Lekki"
    },
    postedBy: "startup_founder",
    hiredProvider: null,
    status: "open",
    createdAt: "2026-07-25T16:00:00Z"
  }
];

export const RESERVED_USERNAMES = [
  "admin",
  "tobjosh",
  "employer",
  "provider",
  "wedding_planner_pro",
  "lounge_manager",
  "tobjosh_events",
  "austin_sounds",
  "learner_dan",
  "startup_founder",
  "deutsch_corp"
];

export const AVATAR_PRESETS = [
  "👑 Gold Crown",
  "💼 Executive Case",
  "🎵 Music Note",
  "🎹 Piano Key",
  "🥁 Drum Set",
  "👨‍💻 Code Wizard",
  "🍽️ Silver Tray",
  "🦁 Golden Lion"
];
