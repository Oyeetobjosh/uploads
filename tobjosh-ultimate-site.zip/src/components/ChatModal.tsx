import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Paperclip, 
  Image as ImageIcon, 
  FileText, 
  ShieldAlert, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  DollarSign, 
  User, 
  Sparkles,
  Download,
  AlertTriangle
} from 'lucide-react';
import { Job, UserProfile } from '../types';

import { db } from '../firebase';
import { collection, doc, setDoc, onSnapshot, query, orderBy } from 'firebase/firestore';

export interface ChatMessage {
  id: string;
  jobId: string;
  senderUsername: string;
  senderFullName: string;
  text: string;
  fileAttachment?: {
    name: string;
    type: 'image' | 'pdf' | 'document';
    url: string;
  };
  statusUpdate?: string;
  timestamp: string;
}

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: Job;
  currentUser: UserProfile;
  onReleaseEscrow: (jobId: string) => void;
  triggerNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export default function ChatModal({
  isOpen,
  onClose,
  job,
  currentUser,
  onReleaseEscrow,
  triggerNotification
}: ChatModalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(`tobjosh_chat_${job.id}`);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'msg-init-1',
        jobId: job.id,
        senderUsername: job.postedBy,
        senderFullName: job.postedBy === currentUser.username ? currentUser.fullName : 'Client',
        text: `Hello! Thanks for connecting regarding "${job.title}". All agreements and payments are securely held in Tobjosh Escrow.`,
        timestamp: new Date(Date.now() - 3600000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  });

  const [inputMessage, setInputMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<{ name: string; type: 'image' | 'pdf' | 'document'; url: string } | null>(null);
  const [etaStatus, setEtaStatus] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Firestore Real-Time Chat Listener across users
  useEffect(() => {
    if (!isOpen || !job.id) return;
    
    try {
      const messagesRef = collection(db, 'chats', job.id, 'messages');
      const unsubscribe = onSnapshot(messagesRef, (snapshot) => {
        if (!snapshot.empty) {
          const remoteMsgs: ChatMessage[] = [];
          snapshot.forEach(docSnap => {
            remoteMsgs.push(docSnap.data() as ChatMessage);
          });
          // Sort by message ID / time
          remoteMsgs.sort((a, b) => a.id.localeCompare(b.id));
          setMessages(remoteMsgs);
          localStorage.setItem(`tobjosh_chat_${job.id}`, JSON.stringify(remoteMsgs));
        }
      }, (err) => {
        console.warn("Firestore chat live sync warning:", err);
      });

      return () => unsubscribe();
    } catch (err) {
      console.warn("Firestore listener init exception:", err);
    }
  }, [isOpen, job.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      triggerNotification("File size exceeds 5MB limit.", "error");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const fileType = file.type.includes('image') ? 'image' : file.type.includes('pdf') ? 'pdf' : 'document';
      setSelectedFile({
        name: file.name,
        type: fileType,
        url: event.target?.result as string
      });
      triggerNotification(`Attached ${file.name}`, "info");
    };
    reader.readAsDataURL(file);
  };

  const saveMessageToFirestoreAndLocal = async (newMsg: ChatMessage) => {
    // Local state update
    setMessages(prev => {
      const updated = [...prev, newMsg];
      localStorage.setItem(`tobjosh_chat_${job.id}`, JSON.stringify(updated));
      return updated;
    });

    // Remote Firestore write for live multi-user sync
    try {
      await setDoc(doc(db, 'chats', job.id, 'messages', newMsg.id), newMsg);
    } catch (err) {
      console.warn("Could not push chat message to Firestore:", err);
    }
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputMessage.trim() && !selectedFile && !etaStatus) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      jobId: job.id,
      senderUsername: currentUser.username,
      senderFullName: currentUser.fullName,
      text: inputMessage.trim(),
      fileAttachment: selectedFile || undefined,
      statusUpdate: etaStatus || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    saveMessageToFirestoreAndLocal(newMsg);
    setInputMessage('');
    setSelectedFile(null);
    setEtaStatus('');
  };

  const handleSendEtaUpdate = (statusText: string) => {
    setEtaStatus(statusText);
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      jobId: job.id,
      senderUsername: currentUser.username,
      senderFullName: currentUser.fullName,
      text: `📍 Live Status Update: ${statusText}`,
      statusUpdate: statusText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    saveMessageToFirestoreAndLocal(newMsg);
    triggerNotification(`Live ETA updated to: "${statusText}"`, "success");
  };

  const isClient = currentUser.username === job.postedBy;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-2xl bg-[#180E09] border border-[#F2C12E]/30 rounded-3xl overflow-hidden text-white flex flex-col h-[90vh] sm:h-[80vh] shadow-2xl font-sans"
        >
          {/* HEADER */}
          <div className="p-4 bg-[#24140F] border-b border-white/10 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-[#F2C12E] text-[#180E09] flex items-center justify-center font-black shrink-0">
                💬
              </div>
              <div className="min-w-0 text-left">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-white truncate">{job.title}</h3>
                  <span className="text-[10px] bg-amber-500/20 text-[#F2C12E] px-2 py-0.5 rounded-full font-bold border border-amber-500/30 shrink-0">
                    ₦{job.budget.toLocaleString()} Escrow
                  </span>
                </div>
                <p className="text-[11px] text-amber-200/60 truncate">
                  Location: {job.location.city}, {job.location.state} • {isClient ? 'Chatting with Provider' : 'Chatting with Client'}
                </p>
              </div>
            </div>

            <button 
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* STRICT SAFETY BANNER (COMPULSORY WARNING) */}
          <div className="p-3 bg-amber-500/10 border-b border-amber-500/30 flex items-start gap-2.5 text-left text-amber-300">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 animate-pulse" />
            <div className="text-[11px] leading-tight">
              <span className="font-extrabold uppercase text-amber-400">Strict Security Warning:</span> Never communicate or transfer funds outside Tobjosh Ultimates! Moving off-platform immediately forfeits Escrow Money Protection and account guarantees.
            </div>
          </div>

          {/* ETA / LIVE STATUS UPDATER BAR */}
          <div className="p-2.5 bg-[#1F110B] border-b border-white/5 flex items-center gap-2 overflow-x-auto text-left">
            <span className="text-[10px] font-black uppercase text-amber-200/70 shrink-0 flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#F2C12E]" /> Live ETA:
            </span>
            {[
              "⏱️ 10 mins away",
              "⏱️ 20 mins away",
              "📍 Arrived on location",
              "🛠️ Work in progress",
              "✅ Work Completed"
            ].map((statusStr) => (
              <button
                key={statusStr}
                onClick={() => handleSendEtaUpdate(statusStr)}
                className="px-2.5 py-1 bg-white/5 hover:bg-[#F2C12E]/20 text-neutral-300 hover:text-[#F2C12E] border border-white/10 hover:border-[#F2C12E]/40 rounded-full text-[10px] font-bold whitespace-nowrap transition-all"
              >
                {statusStr}
              </button>
            ))}
          </div>

          {/* MESSAGES BODY */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-[#130805]">
            {messages.map((msg) => {
              const isMe = msg.senderUsername === currentUser.username;
              return (
                <div 
                  key={msg.id} 
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                >
                  <span className="text-[10px] font-bold text-neutral-400 px-1">
                    {msg.senderFullName} • {msg.timestamp}
                  </span>

                  <div 
                    className={`max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs text-left shadow-md ${
                      isMe 
                        ? 'bg-[#3F271E] text-white border border-[#F2C12E]/30 rounded-tr-none' 
                        : 'bg-[#24140F] text-neutral-200 border border-white/10 rounded-tl-none'
                    }`}
                  >
                    {msg.statusUpdate && (
                      <div className="mb-2 p-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-[#F2C12E] font-bold flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-amber-400" />
                        <span>{msg.statusUpdate}</span>
                      </div>
                    )}

                    {msg.text && <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>}

                    {msg.fileAttachment && (
                      <div className="mt-2.5 p-2 bg-black/40 rounded-xl border border-white/10 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          {msg.fileAttachment.type === 'image' ? (
                            <ImageIcon className="w-4 h-4 text-amber-400 shrink-0" />
                          ) : (
                            <FileText className="w-4 h-4 text-blue-400 shrink-0" />
                          )}
                          <span className="text-[11px] font-mono text-neutral-300 truncate">
                            {msg.fileAttachment.name}
                          </span>
                        </div>
                        <a 
                          href={msg.fileAttachment.url} 
                          download={msg.fileAttachment.name}
                          className="p-1 bg-white/10 hover:bg-white/20 rounded-lg text-white"
                          title="Download attachment"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* ESCROW RELEASE BAR (FOR CLIENT) */}
          {job.status === 'escrow' && (
            <div className="p-3 bg-[#24140F] border-t border-amber-500/20 flex flex-wrap items-center justify-between gap-2 text-left">
              <div>
                <p className="text-xs font-black text-[#F2C12E]">Escrow Fund Locked: ₦{job.budget.toLocaleString()}</p>
                <p className="text-[10px] text-neutral-400">Release funds once provider completes service satisfactorily.</p>
              </div>

              {isClient ? (
                <button
                  onClick={() => onReleaseEscrow(job.id)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-black uppercase rounded-xl shadow-md transition-all flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Release ₦{job.budget.toLocaleString()} to Provider</span>
                </button>
              ) : (
                <div className="px-3 py-1.5 bg-amber-500/10 text-amber-400 rounded-xl text-xs font-bold border border-amber-500/30">
                  Waiting for client release approval
                </div>
              )}
            </div>
          )}

          {/* INPUT FORM */}
          <form onSubmit={handleSendMessage} className="p-3 bg-[#24140F] border-t border-white/10 space-y-2">
            {selectedFile && (
              <div className="flex items-center justify-between p-2 bg-[#180E09] rounded-xl border border-[#F2C12E]/40 text-xs">
                <span className="font-mono text-amber-300 truncate">📎 Attached: {selectedFile.name}</span>
                <button 
                  type="button" 
                  onClick={() => setSelectedFile(null)}
                  className="text-neutral-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="flex items-center gap-2">
              <label className="p-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl cursor-pointer text-amber-300 hover:text-[#F2C12E] transition-colors shrink-0">
                <Paperclip className="w-4 h-4" />
                <input 
                  type="file" 
                  onChange={handleFileUpload} 
                  accept="image/*,.pdf,.txt,.doc,.docx" 
                  className="hidden" 
                />
              </label>

              <input 
                type="text" 
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message securely..."
                className="flex-1 bg-[#130805] border border-white/10 focus:border-[#F2C12E] rounded-2xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 outline-none"
              />

              <button 
                type="submit"
                className="p-2.5 bg-[#F2C12E] hover:bg-[#e0b024] text-[#180E09] font-black rounded-2xl transition-transform active:scale-95 shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
