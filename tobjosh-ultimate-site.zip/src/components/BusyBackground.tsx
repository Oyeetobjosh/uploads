import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  ShieldCheck, 
  Music, 
  Briefcase, 
  Check, 
  Star, 
  MapPin, 
  TrendingUp, 
  Lock,
  Globe,
  UserCheck
} from 'lucide-react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  alpha: number;
}

export default function BusyBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [mousePos, setMousePos] = useState({ x: -1000, y: -1000 });

  // Rolling log ticker inside background to make it look active/busy
  const [activities, setActivities] = useState<string[]>([
    "Escrow Locked: $1,500 by @tobjosh_client",
    "Verified Contractor: @jazz_pianist joined Lagos node",
    "Payment Released: $250.00 for Luxury Catering",
    "Escrow Locked: $450 by @client_lekki",
    "Verified Contract Secured: Tutorials with @edu_tutor",
    "Secure Node: Port Harcourt routing activated",
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setActivities(prev => {
        const copy = [...prev];
        const last = copy.shift();
        if (last) copy.push(last);
        return copy;
      });
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    const particleCount = 60;
    const maxDistance = 120;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initParticles();
    };

    const initParticles = () => {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          radius: Math.random() * 2 + 1,
          alpha: Math.random() * 0.5 + 0.3
        });
      }
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw thin cybertech grid
      ctx.strokeStyle = 'rgba(212, 175, 55, 0.025)';
      ctx.lineWidth = 1;
      const gridSize = 60;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Draw and update particles
      particles.forEach((p, index) => {
        p.x += p.vx;
        p.y += p.vy;

        // Bounce on boundaries
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        // Draw particle
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(212, 175, 55, ${p.alpha})`;
        ctx.shadowBlur = 8;
        ctx.shadowColor = '#D4AF37';
        ctx.fill();
        ctx.shadowBlur = 0; // reset shadow

        // Pull slightly towards mouse
        const dxMouse = mousePos.x - p.x;
        const dyMouse = mousePos.y - p.y;
        const distMouse = Math.sqrt(dxMouse * dxMouse + dyMouse * dyMouse);
        if (distMouse < 200) {
          p.x += dxMouse * 0.005;
          p.y += dyMouse * 0.005;
        }

        // Draw connection lines to other particles
        for (let j = index + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDistance) {
            const alpha = (1 - dist / maxDistance) * 0.15;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(212, 175, 55, ${alpha})`;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }

        // Draw connection line to mouse
        if (distMouse < 180) {
          const alpha = (1 - distMouse / 180) * 0.25;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mousePos.x, mousePos.y);
          ctx.strokeStyle = `rgba(212, 175, 55, ${alpha})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [mousePos]);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-0 select-none">
      
      {/* 1. Base Interactive Particle Starfield Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-65" />

      {/* 2. Pulsing Radial Luxury Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-gradient-to-br from-[#D4AF37]/8 to-transparent blur-[110px] animate-pulse duration-10000" />
      <div className="absolute bottom-[-15%] right-[-10%] w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-amber-600/5 to-transparent blur-[130px] animate-pulse duration-8000" />
      <div className="absolute top-[40%] right-[15%] w-[350px] h-[350px] rounded-full bg-gradient-to-bl from-[#D4AF37]/5 to-transparent blur-[90px] animate-pulse duration-6000" />

      {/* 3. Floating Premium Micro-UI Mockup Cards (Matches User Inspo) */}
      
      {/* CARD A: Floating Live Premium Category (Music Pianist) */}
      <motion.div 
        initial={{ opacity: 0, x: -50, y: 150 }}
        animate={{ 
          opacity: 0.75, 
          x: 40, 
          y: [120, 135, 120],
          rotate: [-1, 1, -1]
        }}
        transition={{
          y: { duration: 6, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 8, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 1.5 }
        }}
        className="absolute left-6 top-[15%] w-60 hidden xl:flex flex-col bg-[#1A0F0A]/90 border border-[#D4AF37]/25 rounded-2xl p-4 shadow-2xl backdrop-blur-md"
      >
        <div className="flex items-center justify-between mb-3">
          <span className="text-[8px] font-mono font-bold tracking-widest text-[#D4AF37] uppercase bg-[#D4AF37]/10 px-2 py-0.5 rounded-full border border-[#D4AF37]/20 flex items-center gap-1">
            <Music className="w-2.5 h-2.5" /> Live Category
          </span>
          <div className="flex items-center gap-0.5 text-amber-400">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-2 h-2 fill-amber-400 text-amber-400" />
            ))}
          </div>
        </div>
        <p className="font-serif text-sm font-bold text-amber-100">Jazz Pianist Showcase</p>
        <p className="text-[10px] text-amber-200/40 mt-1 font-mono flex items-center gap-1">
          <MapPin className="w-3 h-3 text-[#D4AF37]" /> Victoria Island, Lagos
        </p>
        <div className="mt-3 pt-3.5 border-t border-amber-900/10 flex justify-between items-center text-[9px] font-mono text-amber-200/50">
          <span>Hired rate: $150/hr</span>
          <span className="text-emerald-400 flex items-center gap-0.5 font-bold"><Check className="w-3 h-3" /> VERIFIED</span>
        </div>
      </motion.div>

      {/* CARD B: Floating Escrow Ledger Guarantee Card */}
      <motion.div 
        initial={{ opacity: 0, x: 100, y: 80 }}
        animate={{ 
          opacity: 0.7, 
          x: -40, 
          y: [60, 45, 60],
          rotate: [2, -2, 2]
        }}
        transition={{
          y: { duration: 7, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 9, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 1.5 }
        }}
        className="absolute right-6 top-[22%] w-64 hidden xl:flex flex-col bg-[#1A0F0A]/90 border border-[#D4AF37]/20 rounded-2xl p-4 shadow-2xl backdrop-blur-md"
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[8px] font-mono tracking-widest text-[#D4AF37] uppercase font-bold flex items-center gap-1">
            <Lock className="w-3 h-3 text-[#D4AF37]" /> Escrow Ledger
          </span>
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
        </div>
        <p className="font-serif text-base font-black text-amber-100">$2,500.00</p>
        <p className="text-[9px] text-[#D4AF37] font-mono uppercase mt-0.5 tracking-wider font-bold">Locked Secure Holding</p>
        <div className="mt-3.5 space-y-1.5 font-mono text-[8px] text-amber-200/40">
          <div className="flex justify-between"><span>Contract:</span><span className="text-amber-100">#TX-LGS-4089</span></div>
          <div className="flex justify-between"><span>Mutual Release:</span><span className="text-emerald-400 font-bold">READY</span></div>
        </div>
      </motion.div>

      {/* CARD C: Floating Verified Contractor */}
      <motion.div 
        initial={{ opacity: 0, y: 350 }}
        animate={{ 
          opacity: 0.65, 
          x: 40,
          y: [320, 340, 320],
          rotate: [1, -1, 1]
        }}
        transition={{
          y: { duration: 8, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 7, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 1.5 }
        }}
        className="absolute left-10 top-[48%] w-56 hidden xl:flex flex-col bg-[#1A0F0A]/90 border border-amber-500/15 rounded-2xl p-4 shadow-2xl backdrop-blur-md"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center text-sm">
            👑
          </div>
          <div>
            <p className="text-[10px] font-bold text-amber-100">@tobjosh_premium</p>
            <p className="text-[8px] font-mono text-[#D4AF37] uppercase tracking-wider font-bold">Gold Contractor</p>
          </div>
        </div>
        <p className="text-[9.5px] text-amber-200/50 mt-2.5 font-mono line-clamp-2 leading-relaxed">
          Platform-authorized beta tester with multi-sig wallet credentials enabled.
        </p>
        <div className="mt-3 pt-2.5 border-t border-amber-950/20 flex items-center justify-between text-[8px] font-mono text-amber-200/30">
          <span className="flex items-center gap-0.5"><ShieldCheck className="w-3 h-3 text-emerald-400" /> SECURE SLOT</span>
          <span>100% SUCCESS RATE</span>
        </div>
      </motion.div>

      {/* CARD D: Live Dispatch Ticker Activity log in the background bottom-left */}
      <motion.div 
        initial={{ opacity: 0, y: 400 }}
        animate={{ opacity: 0.5, y: 0 }}
        transition={{ delay: 0.8 }}
        className="absolute left-6 bottom-[8%] max-w-[280px] hidden lg:flex flex-col gap-2 bg-gradient-to-t from-[#110906] to-transparent p-4"
      >
        <span className="text-[8px] font-mono font-bold tracking-widest text-[#D4AF37] uppercase flex items-center gap-1">
          <Globe className="w-3 h-3 text-[#D4AF37] animate-spin-slow" /> Real-time System Ledger
        </span>
        <div className="space-y-1.5 h-20 overflow-hidden relative">
          {activities.map((act, i) => (
            <motion.div 
              key={act + i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: i === 0 ? 0.9 : i === 1 ? 0.4 : 0.15, x: 0 }}
              transition={{ duration: 0.4 }}
              className="font-mono text-[9px] text-amber-100/90 truncate flex items-center gap-1.5"
            >
              <span className="w-1 h-1 rounded-full bg-[#D4AF37]" />
              {act}
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* CARD E: Floating verified contractor count stats card */}
      <motion.div 
        initial={{ opacity: 0, x: 100, y: 380 }}
        animate={{ 
          opacity: 0.65, 
          x: -30, 
          y: [360, 345, 360],
          rotate: [-1, 2, -1]
        }}
        transition={{
          y: { duration: 9, repeat: Infinity, ease: "easeInOut" },
          rotate: { duration: 6, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 1.5 }
        }}
        className="absolute right-8 top-[50%] w-56 hidden xl:flex flex-col bg-[#1A0F0A]/90 border border-[#D4AF37]/20 rounded-2xl p-4 shadow-2xl backdrop-blur-md"
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[8px] font-mono tracking-widest text-amber-300 uppercase font-bold flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-amber-300" /> Network Index
          </span>
          <span className="text-[8px] font-mono text-emerald-400 font-bold">ONLINE</span>
        </div>
        <div className="flex items-baseline gap-1 mt-1">
          <h4 className="text-xl font-mono font-black text-amber-100">4,912</h4>
          <span className="text-[8px] font-mono text-emerald-400 font-bold">+18.4%</span>
        </div>
        <p className="text-[9px] text-amber-200/40 font-mono mt-1">Contractors active globally</p>
      </motion.div>

      {/* Drifting Abstract Particles or Petals (Gold Embers) */}
      <div className="absolute inset-0">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 100 + "%", 
              y: "110%", 
              opacity: Math.random() * 0.4 + 0.1, 
              scale: Math.random() * 0.6 + 0.4 
            }}
            animate={{ 
              y: "-10%",
              x: ["0%", "5%", "-5%", "0%"]
            }}
            transition={{
              y: { duration: Math.random() * 15 + 25, repeat: Infinity, ease: "linear" },
              x: { duration: Math.random() * 5 + 5, repeat: Infinity, ease: "easeInOut" }
            }}
            className="absolute w-2 h-2 rounded-full bg-gradient-to-tr from-[#D4AF37] to-amber-600 blur-[2px] opacity-40 pointer-events-none"
            style={{
              left: (i * 18) + "%"
            }}
          />
        ))}
      </div>

    </div>
  );
}
