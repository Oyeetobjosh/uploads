import React from 'react';

interface TobjoshLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  showTagline?: boolean;
  className?: string;
}

export default function TobjoshLogo({ 
  size = 'md', 
  showText = true, 
  showTagline = true, 
  className = '' 
}: TobjoshLogoProps) {
  // Determine sizes
  const svgDimensions = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-36 h-36'
  }[size];

  const titleSize = {
    sm: 'text-base tracking-[0.1em]',
    md: 'text-xl tracking-[0.2em]',
    lg: 'text-3xl tracking-[0.25em]',
    xl: 'text-4xl tracking-[0.3em]'
  }[size];

  const taglineSize = {
    sm: 'text-[7px]',
    md: 'text-[9px]',
    lg: 'text-[11px]',
    xl: 'text-xs'
  }[size];

  return (
    <div className={`flex flex-col items-center text-center select-none ${className}`}>
      {/* High-Fidelity SVG Gold Shield Logo with Interlocking TJ */}
      <svg 
        className={`${svgDimensions} filter drop-shadow-[0_4px_12px_rgba(212,175,55,0.15)] animate-in fade-in duration-700`} 
        viewBox="0 0 160 180" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Rich metallic gold gradient */}
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF2B2" />
            <stop offset="30%" stopColor="#D4AF37" />
            <stop offset="70%" stopColor="#AA7C11" />
            <stop offset="100%" stopColor="#F3E5AB" />
          </linearGradient>
          {/* Subtle gold stroke gradient */}
          <linearGradient id="goldStroke" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#AA7C11" />
            <stop offset="50%" stopColor="#D4AF37" />
            <stop offset="100%" stopColor="#5B4006" />
          </linearGradient>
          {/* Inner shadow or gold glow filter */}
          <filter id="goldGlow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#D4AF37" floodOpacity="0.25" />
          </filter>
        </defs>

        {/* Shield Outer Border */}
        <path 
          d="M 80 15 C 115 15, 140 25, 140 55 C 140 105, 110 145, 80 165 C 50 145, 20 105, 20 55 C 20 25, 45 15, 80 15 Z" 
          stroke="url(#goldStroke)" 
          strokeWidth="3.5" 
          strokeLinejoin="round"
          fill="#1C100B"
          fillOpacity="0.9"
        />

        {/* Shield Inner Inset Line */}
        <path 
          d="M 80 23 C 110 23, 132 31, 132 57 C 132 101, 106 137, 80 155 C 54 137, 28 101, 28 57 C 28 31, 50 23, 80 23 Z" 
          stroke="url(#goldGrad)" 
          strokeWidth="1" 
          strokeOpacity="0.5"
          fill="none"
        />

        {/* Interlocking 'TJ' Letterform */}
        <g filter="url(#goldGlow)">
          {/* 'T' Horizontal Top Bar */}
          <path 
            d="M 45 42 L 115 42 L 115 54 L 105 54 C 105 54, 98 54, 95 62 L 95 110 L 83 110 L 83 54 L 77 54 L 77 110 L 65 110 L 65 62 C 62 54, 55 54, 55 54 L 45 54 Z" 
            fill="url(#goldGrad)" 
          />
          {/* 'J' Hooking Loop */}
          <path 
            d="M 115 62 L 115 105 C 115 125, 105 138, 80 138 C 55 138, 48 122, 48 112 L 62 112 C 62 118, 67 126, 80 126 C 93 126, 101 118, 101 105 L 101 62 Z" 
            fill="url(#goldGrad)" 
          />
        </g>
      </svg>

      {showText && (
        <div className="mt-4 flex flex-col items-center">
          {/* "TOBJOSH" text matching the bold gold logo */}
          <h1 className={`font-serif font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-[#D4AF37] to-[#AA7C11] ${titleSize} uppercase tracking-[0.22em]`}>
            TOBJOSH
          </h1>
          
          {showTagline && (
            <p className={`font-serif italic font-light text-amber-100/80 mt-1.5 ${taglineSize} tracking-[0.08em] flex items-center gap-1 sm:gap-2`}>
              <span>Hyper-Local</span>
              <span className="text-[#D4AF37] font-sans font-normal opacity-40">|</span>
              <span>Gigs</span>
              <span className="text-[#D4AF37] font-sans font-normal opacity-40">|</span>
              <span>Careers</span>
            </p>
          )}
        </div>
      )}
    </div>
  );
}
