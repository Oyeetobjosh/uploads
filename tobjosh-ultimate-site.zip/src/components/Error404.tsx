import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, RefreshCw, UploadCloud, FileImage, Home, AlertCircle, Sparkles } from 'lucide-react';

interface Error404Props {
  onBackToHome: () => void;
  triggerNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export default function Error404({ onBackToHome, triggerNotification }: Error404Props) {
  const [customImage, setCustomImage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [imgLoadError, setImgLoadError] = useState(false);

  // Load custom image from localStorage on mount
  useEffect(() => {
    const savedImg = localStorage.getItem('tobjosh_404_image');
    if (savedImg) {
      setCustomImage(savedImg);
    }
  }, []);

  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      triggerNotification("Unsupported file format! Please upload an image.", "error");
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      if (base64) {
        localStorage.setItem('tobjosh_404_image', base64);
        setCustomImage(base64);
        setImgLoadError(false);
        triggerNotification("Premium 404 illustration uploaded and saved!", "success");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const resetToDefault = () => {
    localStorage.removeItem('tobjosh_404_image');
    setCustomImage(null);
    setImgLoadError(false);
    triggerNotification("Resetting to high-fidelity platform vector illustrations.", "info");
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#D4AF37]/15 pb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono uppercase bg-rose-500/10 text-rose-400 font-bold border border-rose-500/20">
            <ShieldAlert className="w-3.5 h-3.5" /> ERROR CODE: 404
          </span>
          <h2 className="font-serif text-3xl font-bold text-amber-100 mt-2">Gig Not Found</h2>
          <p className="text-xs font-mono text-amber-200/50 uppercase mt-1">Ecosystem index lookup request failed to resolve</p>
        </div>
        
        <button
          onClick={onBackToHome}
          className="flex items-center gap-2 px-5 py-2.5 bg-[#D4AF37] hover:bg-[#b8952d] text-[#110906] rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all shadow-lg shadow-[#D4AF37]/10 shrink-0"
        >
          <Home className="w-4 h-4" /> Return to Gig Hub
        </button>
      </div>

      {/* Main Illustration Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Image / SVG Rendering */}
        <div className="lg:col-span-8 bg-[#160D09] border border-[#D4AF37]/25 rounded-3xl p-6 sm:p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl min-h-[400px]">
          
          <div className="absolute inset-0 pointer-events-none z-0">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] rounded-full bg-[#D4AF37]/5 blur-[60px]" />
          </div>

          <div className="relative z-10 w-full flex flex-col items-center text-center">
            
            {/* Image display */}
            <AnimatePresence mode="wait">
              {(!imgLoadError && (customImage || !imgLoadError)) ? (
                <motion.div
                  key="custom-img"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full flex flex-col items-center"
                >
                  <img
                    src={customImage || "/assets/error_404.png"}
                    alt="TOBJOSH Gig Squad 404 Error"
                    referrerPolicy="no-referrer"
                    onError={() => setImgLoadError(true)}
                    className="w-full h-auto max-h-[380px] object-contain rounded-2xl border border-[#D4AF37]/10 bg-[#1C100B]/40 p-1 shadow-lg"
                  />
                  <p className="text-[10px] font-mono text-amber-200/40 uppercase mt-4 tracking-widest">
                    Active 404 Display Image
                  </p>
                </motion.div>
              ) : (
                /* Premium Hand-Crafted Fallback Vector Scene */
                <motion.div
                  key="fallback-vector"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full flex flex-col items-center py-6"
                >
                  <svg viewBox="0 0 800 450" className="w-full h-auto max-h-[320px] filter drop-shadow-2xl" fill="none" xmlns="http://www.w3.org/2000/svg">
                    {/* Background Soft Panel */}
                    <rect width="800" height="450" rx="24" fill="#1C100B" />
                    <rect width="798" height="448" x="1" y="1" rx="23" stroke="#D4AF37" strokeOpacity="0.1" strokeWidth="2" />
                    
                    {/* Server Rack (Left) */}
                    <g transform="translate(140, 90)">
                      <rect width="120" height="230" rx="8" fill="#2C1810" stroke="#D4AF37" strokeOpacity="0.2" strokeWidth="2" />
                      {/* Servers */}
                      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                        <g key={i} transform={`translate(8, ${12 + i * 30})`}>
                          <rect width="104" height="20" rx="4" fill="#110906" />
                          <circle cx="92" cy="10" r="2.5" fill={i === 2 ? "#EF4444" : "#10B981"} className={i === 2 ? "animate-pulse" : ""} />
                          <rect width="30" height="3" x="8" y="8" rx="1.5" fill="#D4AF37" fillOpacity="0.3" />
                        </g>
                      ))}
                      {/* Cables & Smoke */}
                      <path d="M 60 -10 C 60 -30, 45 -40, 50 -50" stroke="#6B7280" strokeWidth="3" strokeLinecap="round" strokeDasharray="3 3" className="animate-pulse" />
                      <circle cx="50" cy="-55" r="8" fill="#4B5563" opacity="0.4" />
                      <circle cx="55" cy="-65" r="12" fill="#4B5563" opacity="0.3" />
                    </g>

                    {/* Cables on the floor */}
                    <path d="M 230 320 C 270 360, 310 320, 350 340 S 400 360, 420 320" stroke="#D4AF37" strokeWidth="5" strokeLinecap="round" opacity="0.3" fill="none" />
                    <path d="M 210 300 C 250 340, 320 350, 360 310 S 430 350, 450 330" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" opacity="0.2" fill="none" />

                    {/* Rooster character (Center) */}
                    <g transform="translate(380, 150)">
                      {/* Chicken Body */}
                      <circle cx="0" cy="50" r="55" fill="#B45309" stroke="#110906" strokeWidth="4" />
                      <circle cx="0" cy="50" r="45" fill="#D97706" />
                      {/* Comb & wattles */}
                      <path d="M -15 -12 C -15 -30, 15 -30, 15 -12 Z" fill="#EF4444" />
                      <path d="M -10 95 C -10 110, 10 110, 10 95 Z" fill="#EF4444" />
                      {/* Eyes */}
                      <circle cx="-15" cy="35" r="8" fill="#FFFFFF" stroke="#110906" strokeWidth="2.5" />
                      <circle cx="-13" cy="35" r="3" fill="#110906" />
                      <circle cx="15" cy="35" r="8" fill="#FFFFFF" stroke="#110906" strokeWidth="2.5" />
                      <circle cx="13" cy="35" r="3" fill="#110906" />
                      {/* Beak */}
                      <path d="M -8 48 L 8 48 L 0 65 Z" fill="#F59E0B" stroke="#110906" strokeWidth="2.5" />
                      
                      {/* Construction Helmet */}
                      <path d="M -45 20 C -45 -15, 45 -15, 45 20 Z" fill="#FBBF24" stroke="#110906" strokeWidth="3.5" />
                      <rect x="-50" y="15" width="100" height="6" rx="3" fill="#FBBF24" stroke="#110906" strokeWidth="2.5" />
                      <rect x="-10" y="-12" width="20" height="15" fill="#D97706" />

                      {/* Overalls */}
                      <rect x="-30" y="80" width="60" height="40" rx="8" fill="#F3F4F6" stroke="#110906" strokeWidth="3" />
                      {/* Text label */}
                      <text x="0" y="98" fill="#1F2937" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">GIG SQUAD</text>
                      
                      {/* Left wing holding sign */}
                      <path d="M 40 70 C 60 70, 75 50, 70 40" stroke="#110906" strokeWidth="12" strokeLinecap="round" />
                      <path d="M 40 70 C 60 70, 75 50, 70 40" stroke="#F3F4F6" strokeWidth="8" strokeLinecap="round" />

                      {/* Sign Post & Board */}
                      <g transform="translate(100, -50)">
                        <rect x="-6" y="20" width="12" height="150" fill="#78350F" />
                        <g transform="rotate(5)">
                          <rect x="-80" y="10" width="160" height="70" rx="8" fill="#FFFBEB" stroke="#110906" strokeWidth="4" />
                          <text x="0" y="32" fill="#110906" fontSize="15" fontWeight="black" fontFamily="sans-serif" textAnchor="middle">404 - ERROR</text>
                          <text x="0" y="52" fill="#B45309" fontSize="11" fontWeight="bold" fontFamily="monospace" textAnchor="middle">GIG NOT FOUND!</text>
                          <text x="0" y="68" fill="#6B7280" fontSize="8" fontWeight="bold" fontFamily="sans-serif" textAnchor="middle">tobjosh gig squad</text>
                        </g>
                      </g>
                    </g>

                    {/* Question marks */}
                    <text x="320" y="120" fill="#D4AF37" fontSize="30" fontWeight="bold" fontFamily="serif" opacity="0.6">?</text>
                    <text x="530" y="130" fill="#D4AF37" fontSize="24" fontWeight="bold" fontFamily="serif" opacity="0.4">?</text>

                    {/* Bottom Caption */}
                    <text x="400" y="410" fill="#F5F2F0" fontSize="14" fontWeight="bold" fontFamily="sans-serif" textAnchor="middle">Looks like this job got lost in the cables.</text>
                    <text x="400" y="430" fill="#D4AF37" fontSize="11" fontFamily="monospace" textAnchor="middle">LET'S GET YOU BACK TO WORK!</text>
                  </svg>
                  <p className="text-[10px] font-mono text-rose-400 uppercase mt-4 tracking-widest flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> Custom Image Not Loaded. Showing Fallback Vector.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        </div>

        {/* Right Column: Upload / Customizer Panel */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* File Drag-and-Drop Uploader */}
          <div className="bg-[#160D09] border border-[#D4AF37]/20 rounded-3xl p-6 space-y-4">
            <div>
              <h4 className="font-mono text-xs font-bold text-amber-100 uppercase tracking-wider flex items-center gap-1.5">
                <UploadCloud className="w-4 h-4 text-[#D4AF37]" /> Upload Custom Page Image
              </h4>
              <p className="text-[10px] text-amber-200/40 uppercase mt-1 leading-relaxed">
                Drag & drop or select an image file to replace the 404 display instantly.
              </p>
            </div>

            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('error-image-upload')?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${
                isDragging 
                  ? 'border-[#D4AF37] bg-[#D4AF37]/5' 
                  : 'border-[#D4AF37]/20 hover:border-[#D4AF37]/50 bg-[#1C100B]/40'
              }`}
            >
              <input 
                id="error-image-upload"
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="p-3 bg-[#D4AF37]/10 rounded-full text-[#D4AF37]">
                <FileImage className="w-6 h-6" />
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-amber-100">Click to choose image</p>
                <p className="text-[9px] text-amber-200/40 uppercase mt-1">or drag and drop it here</p>
              </div>
            </div>

            {customImage && (
              <button
                onClick={resetToDefault}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-rose-500/25 text-rose-400 font-mono text-[10px] font-bold uppercase tracking-wider hover:bg-rose-500/10 transition-all"
              >
                <RefreshCw className="w-3 h-3" /> Clear Custom & Use Default
              </button>
            )}
          </div>

          {/* Quick Stats/Tip Card */}
          <div className="bg-[#1C100B] border border-[#D4AF37]/10 rounded-3xl p-6 space-y-3">
            <h4 className="font-mono text-xs font-bold text-[#D4AF37] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" /> Premium Integration
            </h4>
            <div className="text-[10px] font-mono text-amber-200/50 space-y-2 leading-relaxed uppercase">
              <p>• Stores custom image base64 locally on browser memory.</p>
              <p>• Perfect for demonstrating customized client or brand environments.</p>
              <p>• Fallback SVG vector ensures zero downtime or broken images.</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
