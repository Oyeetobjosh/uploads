import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Briefcase, 
  Wallet, 
  ShieldCheck, 
  Compass, 
  MapPin, 
  TrendingUp, 
  Award, 
  Plus, 
  Clock, 
  ExternalLink, 
  CheckCircle2,
  Car,
  Package,
  Wrench,
  Eye,
  EyeOff,
  ChevronRight,
  QrCode,
  Lock,
  ArrowDownLeft,
  X,
  CreditCard,
  Wifi,
  Tv,
  Zap,
  Phone,
  UserCheck,
  Percent,
  TrendingDown
} from 'lucide-react';
import { Job, UserProfile } from '../types';

interface HomeRenovationProps {
  currentUser: UserProfile;
  jobs: Job[];
  setActiveTab: (tab: 'home' | 'gigs' | 'errands' | 'wallet' | 'profile' | 'settings' | '404') => void;
  setSelectedJob: (job: Job | null) => void;
  setShowPostModal: (show: boolean) => void;
  setShowFundModal: (show: boolean) => void;
  setShowPaystackModal?: (show: boolean) => void;
  setShowKycModal?: (show: boolean) => void;
  triggerNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
  showBalance: boolean;
  setShowBalance: (show: boolean) => void;
  updateUserBalance: (newBalance: number) => void;
}

export default function HomeRenovation({
  currentUser,
  jobs,
  setActiveTab,
  setSelectedJob,
  setShowPostModal,
  setShowFundModal,
  setShowPaystackModal,
  setShowKycModal,
  triggerNotification,
  showBalance,
  setShowBalance,
  updateUserBalance
}: HomeRenovationProps) {
  // Modal states for interactive features
  const [activeTracker, setActiveTracker] = useState<string | null>(null);
  const [showBillModal, setShowBillModal] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showVaultModal, setShowVaultModal] = useState(false);

  // Bill payment state
  const [billType, setBillType] = useState<'electricity' | 'airtime' | 'cable' | 'internet'>('electricity');
  const [billAmount, setBillAmount] = useState('5000');
  const [billAccount, setBillAccount] = useState('');
  const [isPayingBill, setIsPayingBill] = useState(false);

  // Loan state
  const [loanAmount, setLoanAmount] = useState('50000');
  const [isProcessingLoan, setIsProcessingLoan] = useState(false);

  // Vault state
  const [vaultAmount, setVaultAmount] = useState('20000');
  const [isProcessingVault, setIsProcessingVault] = useState(false);

  // ID Verification state
  const [ninNumber, setNinNumber] = useState('');
  const [isVerifyingId, setIsVerifyingId] = useState(false);

  // Handler to perform a bill payment
  const handlePayBillSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(billAmount);
    if (isNaN(amount) || amount <= 0) {
      triggerNotification("Please specify a valid payment amount.", "error");
      return;
    }
    if (currentUser.balance < amount) {
      triggerNotification("Insufficient funds in your Tobjosh wallet for this transaction.", "error");
      return;
    }

    setIsPayingBill(true);
    setTimeout(() => {
      const remaining = currentUser.balance - amount;
      updateUserBalance(remaining);
      setIsPayingBill(false);
      setShowBillModal(false);
      triggerNotification(`Utility bill paid successfully! ₦${amount.toLocaleString()} deducted from balance.`, "success");
    }, 1200);
  };

  // Handler to request a quick micro-credit loan
  const handleLoanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(loanAmount);
    if (isNaN(amount) || amount <= 0 || amount > 100000) {
      triggerNotification("Micro-credit loan limit is ₦100,000 max.", "error");
      return;
    }

    setIsProcessingLoan(true);
    setTimeout(() => {
      const expanded = currentUser.balance + amount;
      updateUserBalance(expanded);
      setIsProcessingLoan(false);
      setShowLoanModal(false);
      triggerNotification(`Micro-credit loan of ₦${amount.toLocaleString()} approved and instantly deposited!`, "success");
    }, 1500);
  };

  // Handler for secure vault interest locking
  const handleVaultSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(vaultAmount);
    if (isNaN(amount) || amount <= 0) {
      triggerNotification("Please specify a valid lock amount.", "error");
      return;
    }
    if (currentUser.balance < amount) {
      triggerNotification("Insufficient funds available to transfer into high-yield vault.", "error");
      return;
    }

    setIsProcessingVault(true);
    setTimeout(() => {
      const remaining = currentUser.balance - amount;
      updateUserBalance(remaining);
      setIsProcessingVault(false);
      setShowVaultModal(false);
      triggerNotification(`Vault secured! ₦${amount.toLocaleString()} locked at 12.5% APY yield index.`, "success");
    }, 1400);
  };

  // Handler for premium ID verification
  const handleVerifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (ninNumber.trim().length !== 11 || isNaN(Number(ninNumber))) {
      triggerNotification("National Identification Number (NIN) must be exactly 11 digits.", "error");
      return;
    }

    setIsVerifyingId(true);
    setTimeout(() => {
      setIsVerifyingId(false);
      setShowVerifyModal(false);
      triggerNotification("Verification files approved! Premium Partner ID badge activated.", "success");
    }, 1600);
  };

  // Live progress details for tracker drawer
  const trackingDetails: Record<string, {
    title: string;
    subtitle: string;
    icon: any;
    color: string;
    stages: string[];
    currentStage: number;
    description: string;
    partnerName: string;
    eta: string;
  }> = {
    driver: {
      title: "Driver Arriving",
      subtitle: "On my way • 30 mins away",
      icon: Car,
      color: "#10B981",
      stages: ["Order Confirmed", "Driver Assigned", "En Route to Pickup", "Arriving at Destination"],
      currentStage: 2,
      description: "Hired driver is transporting premium music gear from Ikeja Mainland storage depot to Victoria Island wedding hall.",
      partnerName: "Kunle A.",
      eta: "30 Mins"
    },
    grocery: {
      title: "Grocery Delivery",
      subtitle: "Almost there • 5 mins away",
      icon: Package,
      color: "#3B82F6",
      stages: ["Order Created", "Items Packed", "Out for Delivery", "Delivered & Secure"],
      currentStage: 3,
      description: "Luxury catering inventory list (premium wines and customized gold pastry platters) being delivered directly to the VIP lounge.",
      partnerName: "Emeka O.",
      eta: "5 Mins"
    },
    plumber: {
      title: "Plumber",
      subtitle: "On my way • 15 mins away",
      icon: Wrench,
      color: "#8B5CF6",
      stages: ["Request Lodged", "Technician Dispatched", "En Route", "Repair Commenced"],
      currentStage: 2,
      description: "Verified plumbing contractor dispatched to rectify drainage network flow inside the VIP corporate lounge.",
      partnerName: "Tunde S.",
      eta: "15 Mins"
    }
  };

  const currentTracker = activeTracker ? trackingDetails[activeTracker] : null;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12 text-[#2B1610]">
      
      {/* 1. Merged Banner & Total Balance Card (Combined 2 & 5) */}
      <div className="relative overflow-hidden bg-[#2C1810] border border-[#F2C12E]/30 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col lg:flex-row items-stretch justify-between gap-6 group transition-all duration-300 hover:shadow-2xl">
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden rounded-3xl">
          <div className="absolute top-[-50px] right-[-50px] w-72 h-72 rounded-full bg-[#F2C12E]/5 blur-[70px] transition-all group-hover:scale-110" />
          <div className="absolute bottom-[-50px] left-[-50px] w-64 h-64 rounded-full bg-amber-500/5 blur-[70px]" />
        </div>

        {/* Left Side: Welcome Message & Action Buttons */}
        <div className="relative z-10 flex-1 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-amber-500/20 text-[#F2C12E] text-[10px] font-sans font-extrabold uppercase rounded-full border border-amber-500/30">
                {currentUser.isKycVerified ? '✓ Identity Verified Account' : '⚠️ Pending Identity Verification'}
              </span>
            </div>
            <h1 className="font-sans text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-none">
              Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F2C12E] to-amber-200">{currentUser.fullName}! 👋</span>
            </h1>
            <p className="font-sans text-xs sm:text-sm text-amber-100/70 leading-relaxed max-w-md font-medium">
              Find verified gigs across all 36 Nigerian states or hire skilled talent with 100% Escrow Guarantee.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-4">
            <button 
              onClick={() => setActiveTab('gigs')}
              className="px-6 py-2.5 bg-[#F2C12E] hover:bg-[#dbad24] text-[#2C1810] rounded-xl text-xs font-sans font-extrabold uppercase tracking-wider transition-all shadow-md active:scale-[0.98]"
            >
              Find Work
            </button>
            <button 
              onClick={() => setShowPostModal(true)}
              className="px-6 py-2.5 bg-[#3F271E] hover:bg-[#4E3126] text-white border border-[#F2C12E]/20 rounded-xl text-xs font-sans font-bold uppercase tracking-wider transition-all"
            >
              Post a Job
            </button>
          </div>
        </div>

        {/* Right Side: Integrated Golden Total Balance Module (Merged 5) */}
        <div className="relative z-10 bg-[#F2C12E] rounded-2xl p-6 text-[#2C1810] shadow-md flex flex-col justify-between min-w-full lg:min-w-[320px] lg:max-w-[360px]">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-sans font-extrabold uppercase text-[#2C1810]/60 tracking-wider block">Total Balance</span>
              <div className="flex items-center gap-2">
                <h3 className="font-sans text-3xl font-black text-[#2C1810] tracking-tight">
                  {showBalance ? `₦${currentUser.balance.toLocaleString()}` : "₦••••••"}
                </h3>
                <button 
                  onClick={() => setShowBalance(!showBalance)}
                  className="p-1.5 hover:bg-black/10 rounded-lg text-[#2C1810]/70 hover:text-[#2C1810] transition-all"
                >
                  {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <div className="p-2.5 bg-[#2C1810]/10 rounded-xl text-[#2C1810] border border-black/5">
              <Wallet className="w-5 h-5" />
            </div>
          </div>

          <div className="space-y-3 pt-4">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowBillModal(true)}
                className="flex-1 py-2 bg-[#2C1810] hover:bg-[#3D2319] text-white rounded-xl text-[10px] font-sans font-extrabold uppercase tracking-wider transition-all text-center"
              >
                ⚡ Pay Bills
              </button>
              <button 
                onClick={() => setShowKycModal ? setShowKycModal(true) : setShowVerifyModal(true)}
                className="flex-1 py-2 border border-[#2C1810]/30 hover:border-[#2C1810] text-[#2C1810] hover:bg-white/10 rounded-xl text-[10px] font-sans font-extrabold uppercase tracking-wider transition-all text-center flex items-center justify-center gap-1"
              >
                <span>🛡️ Verify ID</span>
                {currentUser.isKycVerified && <span className="text-[9px] bg-emerald-600 text-white px-1 rounded font-bold">✓</span>}
              </button>
            </div>

            {/* Quick Actions Row */}
            <div className="flex items-center justify-between pt-2.5 border-t border-[#2C1810]/15 text-[9px] font-sans font-extrabold uppercase text-[#2C1810]/80 px-1">
              <button onClick={() => setShowQrModal(true)} className="flex items-center gap-1 hover:text-black transition-colors">
                <QrCode className="w-3.5 h-3.5" />
                <span>Scan</span>
              </button>
              <button onClick={() => setShowLoanModal(true)} className="flex items-center gap-1 hover:text-black transition-colors">
                <Percent className="w-3.5 h-3.5" />
                <span>Loan</span>
              </button>
              <button onClick={() => setShowVaultModal(true)} className="flex items-center gap-1 hover:text-black transition-colors">
                <Lock className="w-3.5 h-3.5" />
                <span>Vault</span>
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* 3. High-Fidelity Interactive Modals */}
      
      {/* Tracker Details Sheet Modal */}
      <AnimatePresence>
        {activeTracker && currentTracker && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-[#2B1610]"
            >
              <button 
                onClick={() => setActiveTracker(null)} 
                className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-5">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-[#F5EFE6] text-[#2C1810]">
                    <currentTracker.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-sans text-base font-extrabold uppercase tracking-wide">{currentTracker.title}</h3>
                    <p className="text-xs text-[#2C1810]/50 font-medium">Status Dispatch Center</p>
                  </div>
                </div>

                <div className="p-4 bg-[#FAF6F0] rounded-2xl border border-[#EBE6DD] space-y-1 text-xs">
                  <p className="font-semibold text-[#2C1810]">Contract Information:</p>
                  <p className="text-[#2C1810]/70 font-medium leading-relaxed">{currentTracker.description}</p>
                </div>

                {/* Milestone Stepper */}
                <div className="space-y-3.5 pl-3">
                  {currentTracker.stages.map((stage, idx) => {
                    const isPassed = idx < currentTracker.currentStage;
                    const isCurrent = idx === currentTracker.currentStage;
                    return (
                      <div key={idx} className="flex items-start gap-3 relative">
                        {idx < currentTracker.stages.length - 1 && (
                          <div className={`absolute left-2.5 top-6 bottom-0 w-0.5 h-5 ${
                            isPassed ? 'bg-emerald-500' : 'bg-[#EBE6DD]'
                          }`} />
                        )}
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                          isPassed ? 'bg-emerald-500 text-white' : isCurrent ? 'bg-[#F2C12E] text-[#2C1810] animate-pulse ring-4 ring-[#F2C12E]/20' : 'bg-[#F5EFE6] text-[#2C1810]/40'
                        }`}>
                          {isPassed ? "✓" : idx + 1}
                        </div>
                        <div className="text-xs font-sans">
                          <p className={`font-black uppercase tracking-wide ${isCurrent ? 'text-[#2C1810]' : isPassed ? 'text-[#2C1810]/80' : 'text-[#2C1810]/30'}`}>
                            {stage}
                          </p>
                          {isCurrent && (
                            <p className="text-[10px] text-amber-600 font-bold mt-0.5">Active Tracker Node - {currentTracker.eta} ETA</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex gap-4 border-t border-[#EBE6DD] pt-4 text-xs font-sans">
                  <div className="flex-1">
                    <span className="block text-[9px] uppercase font-bold text-[#2C1810]/40">Partner Name:</span>
                    <span className="font-black text-[#2C1810]">{currentTracker.partnerName}</span>
                  </div>
                  <div className="flex-1 text-right">
                    <span className="block text-[9px] uppercase font-bold text-[#2C1810]/40">Security Deposit:</span>
                    <span className="font-black text-[#10B981]">Escrow Protected</span>
                  </div>
                </div>

                <button 
                  onClick={() => setActiveTracker(null)}
                  className="w-full py-3 bg-[#2C1810] hover:bg-[#3D2319] text-white text-xs font-bold uppercase tracking-wider rounded-2xl transition-all"
                >
                  Return to Dashboard
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "Pay Bills" Modal */}
      <AnimatePresence>
        {showBillModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-[#2B1610]"
            >
              <button 
                onClick={() => setShowBillModal(false)} 
                className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]"
              >
                <X className="w-5 h-5" />
              </button>

              <form onSubmit={handlePayBillSubmit} className="space-y-4 font-sans text-xs">
                <div className="text-center pb-2">
                  <h3 className="text-lg font-extrabold uppercase tracking-wide text-[#2C1810]">⚡ Pay Bills</h3>
                  <p className="text-[10px] uppercase text-[#2C1810]/50 tracking-wider font-semibold mt-0.5">Naira Utility Settlement Terminal</p>
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'electricity', label: 'Power', icon: Zap },
                    { id: 'airtime', label: 'Airtime', icon: Phone },
                    { id: 'cable', label: 'Cable', icon: Tv },
                    { id: 'internet', label: 'Data', icon: Wifi }
                  ].map((item) => {
                    const Icon = item.icon;
                    const isActive = billType === item.id;
                    return (
                      <button
                        type="button"
                        key={item.id}
                        onClick={() => setBillType(item.id as any)}
                        className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                          isActive 
                            ? 'bg-[#F2C12E] text-[#2C1810] border-[#F2C12E] shadow-sm' 
                            : 'bg-[#FAF6F0] text-[#2C1810]/50 border-[#EBE6DD] hover:border-[#F2C12E]/30'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-[8px] font-extrabold uppercase">{item.label}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] uppercase font-bold text-[#2C1810]/50">Meter or Account Number:</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 54091823901" 
                    value={billAccount}
                    onChange={(e) => setBillAccount(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EBE6DD] rounded-xl text-xs text-[#2C1810] placeholder-[#2C1810]/30 outline-none focus:border-[#F2C12E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] uppercase font-bold text-[#2C1810]/50">Payment Amount (₦):</label>
                  <input 
                    type="number" 
                    placeholder="e.g. 5000" 
                    value={billAmount}
                    onChange={(e) => setBillAmount(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EBE6DD] rounded-xl text-xs font-black text-[#2C1810] outline-none focus:border-[#F2C12E]"
                  />
                </div>

                <div className="p-3 bg-[#FAF6F0] rounded-xl border border-[#EBE6DD] flex justify-between items-center text-[10px]">
                  <span className="text-[#2C1810]/50 font-bold uppercase">Escrow Lock Protection:</span>
                  <span className="text-emerald-500 font-extrabold uppercase">Active</span>
                </div>

                <button 
                  type="submit" 
                  disabled={isPayingBill}
                  className="w-full py-3 bg-[#2C1810] hover:bg-[#3D2319] text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all disabled:opacity-40"
                >
                  {isPayingBill ? 'Processing instant payment...' : 'Confirm Bill Payment'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "Verify ID" Modal */}
      <AnimatePresence>
        {showVerifyModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-[#2B1610]"
            >
              <button 
                onClick={() => setShowVerifyModal(false)} 
                className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]"
              >
                <X className="w-5 h-5" />
              </button>

              <form onSubmit={handleVerifySubmit} className="space-y-4 font-sans text-xs">
                <div className="text-center pb-2">
                  <h3 className="text-lg font-extrabold uppercase tracking-wide text-[#2C1810]">🛡️ Verification</h3>
                  <p className="text-[10px] uppercase text-[#2C1810]/50 tracking-wider font-semibold mt-0.5">National identity slot protection</p>
                </div>

                <div className="p-4 bg-[#FAF6F0] rounded-2xl border border-[#EBE6DD] space-y-2 leading-relaxed">
                  <p className="font-bold">Ecosystem Verification Protocol:</p>
                  <p className="text-[#2C1810]/60">
                    To maintain an offline, fraud-proof gig atmosphere, verify your status using your 11-digit NIN or Bank Verification code.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] uppercase font-bold text-[#2C1810]/50">Enter 11-digit NIN Number:</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 10293049182" 
                    maxLength={11}
                    value={ninNumber}
                    onChange={(e) => setNinNumber(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EBE6DD] rounded-xl text-xs text-[#2C1810] placeholder-[#2C1810]/30 outline-none focus:border-[#F2C12E]"
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isVerifyingId}
                  className="w-full py-3 bg-[#F2C12E] hover:bg-[#dbad24] text-[#2C1810] text-xs font-bold uppercase tracking-wider rounded-xl transition-all"
                >
                  {isVerifyingId ? 'Validating ID credentials...' : 'Verify Identity'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "Scan" (QR Code) Modal */}
      <AnimatePresence>
        {showQrModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-xs bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-center text-[#2B1610]"
            >
              <button onClick={() => setShowQrModal(false)} className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-4">
                <h3 className="text-base font-extrabold uppercase tracking-wide">Scan QR Code</h3>
                <p className="text-[10px] uppercase text-[#2C1810]/50 tracking-wider">Instant contract verification</p>

                <div className="w-48 h-48 bg-[#FAF6F0] border border-[#EBE6DD] rounded-2xl mx-auto flex items-center justify-center p-4 relative group">
                  <div className="absolute inset-4 border-2 border-dashed border-[#F2C12E] rounded-xl animate-pulse" />
                  <QrCode className="w-24 h-24 text-[#2C1810]" />
                </div>

                <p className="text-[10px] text-[#2C1810]/60 font-medium">
                  Scan another partner's phone screen to securely lock escrow contracts or verify completed work.
                </p>

                <button 
                  onClick={() => setShowQrModal(false)}
                  className="w-full py-2.5 bg-[#FAF6F0] hover:bg-[#F5EFE6] text-[#2C1810] text-[11px] font-bold uppercase tracking-wider rounded-xl transition-all"
                >
                  Close Scanner
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "Loan" Modal */}
      <AnimatePresence>
        {showLoanModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-[#2B1610]"
            >
              <button onClick={() => setShowLoanModal(false)} className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>

              <form onSubmit={handleLoanSubmit} className="space-y-4 font-sans text-xs">
                <div className="text-center pb-2">
                  <h3 className="text-lg font-extrabold uppercase tracking-wide text-[#2C1810]">📈 Quick Loan</h3>
                  <p className="text-[10px] uppercase text-[#2C1810]/50 tracking-wider font-semibold mt-0.5">Micro-credit partner funding</p>
                </div>

                <div className="p-4 bg-[#FAF6F0] rounded-2xl border border-[#EBE6DD] space-y-1.5 leading-relaxed">
                  <p className="font-bold">Instant Liquidity injection:</p>
                  <p className="text-[#2C1810]/60">
                    Need instant capital to bid on a gig or hire contractors? Request up to ₦100,000 at 0% interest for 14 days.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] uppercase font-bold text-[#2C1810]/50">Loan Amount (₦):</label>
                  <input 
                    type="number" 
                    placeholder="e.g. 50000" 
                    max={100000}
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EBE6DD] rounded-xl text-xs font-black text-[#2C1810] outline-none focus:border-[#F2C12E]"
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isProcessingLoan}
                  className="w-full py-3 bg-[#F2C12E] hover:bg-[#dbad24] text-[#2C1810] text-xs font-bold uppercase tracking-wider rounded-xl transition-all"
                >
                  {isProcessingLoan ? 'Authorizing credit line...' : 'Confirm Request'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "Vault" Modal */}
      <AnimatePresence>
        {showVaultModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-white border border-[#EBE6DD] p-6 rounded-3xl relative shadow-2xl text-[#2B1610]"
            >
              <button onClick={() => setShowVaultModal(false)} className="absolute top-5 right-5 text-[#2C1810]/60 hover:text-[#2C1810]">
                <X className="w-5 h-5" />
              </button>

              <form onSubmit={handleVaultSubmit} className="space-y-4 font-sans text-xs">
                <div className="text-center pb-2">
                  <h3 className="text-lg font-extrabold uppercase tracking-wide text-[#2C1810]">🔒 Secure Vault</h3>
                  <p className="text-[10px] uppercase text-[#2C1810]/50 tracking-wider font-semibold mt-0.5">High-yield capital locking</p>
                </div>

                <div className="p-4 bg-[#FAF6F0] rounded-2xl border border-[#EBE6DD] space-y-1.5 leading-relaxed">
                  <p className="font-bold">Yield Locking Index:</p>
                  <p className="text-[#2C1810]/60">
                    Lock your excess Naira earnings inside our compound vault, yielding up to 12.5% APY interest paid out daily.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="block text-[9px] uppercase font-bold text-[#2C1810]/50">Vault Deposit Amount (₦):</label>
                  <input 
                    type="number" 
                    placeholder="e.g. 20000" 
                    value={vaultAmount}
                    onChange={(e) => setVaultAmount(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-[#FAF6F0] border border-[#EBE6DD] rounded-xl text-xs font-black text-[#2C1810] outline-none focus:border-[#F2C12E]"
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isProcessingVault}
                  className="w-full py-3 bg-[#2C1810] hover:bg-[#3D2319] text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all"
                >
                  {isProcessingVault ? 'Locking liquidity nodes...' : 'Confirm Locking Transfer'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
