import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ShieldCheck, 
  CheckCircle2, 
  CreditCard, 
  Building, 
  GraduationCap, 
  Camera, 
  Loader2, 
  Lock,
  Upload,
  AlertTriangle,
  FileCheck,
  Eye,
  ShieldAlert
} from 'lucide-react';
import { UserProfile } from '../types';

interface KycVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onVerifySuccess: (type: 'NIN' | 'BVN' | 'Student ID', kycNumber: string) => void;
  triggerNotification: (msg: string, type: 'success' | 'error' | 'info') => void;
  isCompulsory?: boolean;
}

export default function KycVerificationModal({
  isOpen,
  onClose,
  currentUser,
  onVerifySuccess,
  triggerNotification,
  isCompulsory = false
}: KycVerificationModalProps) {
  const [kycType, setKycType] = useState<'NIN' | 'BVN' | 'Student ID'>('NIN');
  const [kycNumber, setKycNumber] = useState('');
  const [documentFile, setDocumentFile] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [step, setStep] = useState<'form' | 'camera' | 'done'>('form');
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  if (!isOpen) return null;

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setDocumentFile(event.target?.result as string);
      triggerNotification("Document photo attached successfully!", "info");
    };
    reader.readAsDataURL(file);
  };

  const handleStartVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!kycNumber || kycNumber.length < 8) {
      triggerNotification(`Please enter a valid ${kycType} number (min 8 digits).`, "error");
      return;
    }
    setStep('camera');
    startCamera();
  };

  const startCamera = async () => {
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn("Camera fallback or permission denied:", err);
      setCameraActive(false);
    }
  };

  const handleSimulateFacialScan = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setStep('done');
      triggerNotification(`KYC Verification Approved! ${kycType} status attached to your Tobjosh profile.`, "success");
      onVerifySuccess(kycType, kycNumber);
    }, 2500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-xl bg-[#180E09] border border-[#F2C12E]/40 rounded-3xl p-6 md:p-8 text-white relative shadow-2xl font-sans max-h-[92vh] overflow-y-auto"
        >
          {/* Close button hidden if compulsory */}
          {!isCompulsory && (
            <button 
              onClick={onClose}
              className="absolute top-5 right-5 text-neutral-400 hover:text-white p-1.5 rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-3.5 mb-6 text-left">
            <div className="w-11 h-11 rounded-2xl bg-[#F2C12E] flex items-center justify-center text-[#180E09] font-black shrink-0 shadow-lg">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-[#F2C12E] tracking-tight uppercase">Compulsory Identity Verification</h3>
                {isCompulsory && (
                  <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-500/40 px-2 py-0.5 rounded-full font-bold">
                    Required Gate
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-200/70 font-medium">Powered by Didit Free Startup KYC Protocol (ID Verification & 3D Liveness)</p>
            </div>
          </div>

          {step === 'form' && (
            <form onSubmit={handleStartVerification} className="space-y-5 text-left">
              {/* Mandatory Notice */}
              <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-200 leading-snug">
                  <span className="font-extrabold text-amber-400 uppercase">Platform Safety Policy:</span> All creators, employers, and gig runners must complete compulsory identity verification before posting or accepting jobs to prevent fraud or impersonation.
                </div>
              </div>

              {/* Selector */}
              <div>
                <label className="block text-[11px] font-extrabold uppercase text-amber-200/80 mb-2">
                  1. Select Verification Document
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'NIN', label: 'NIN', desc: 'National ID Slip', icon: CreditCard },
                    { id: 'BVN', label: 'BVN', desc: 'Bank Verification', icon: Building },
                    { id: 'Student ID', label: 'Student ID', desc: 'Campus ID Card', icon: GraduationCap }
                  ].map((item) => {
                    const Icon = item.icon;
                    const active = kycType === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setKycType(item.id as any)}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          active 
                            ? 'bg-[#3F271E] border-[#F2C12E] text-[#F2C12E] shadow-sm' 
                            : 'bg-[#24140F] border-white/5 text-neutral-400 hover:bg-[#3F271E]/40'
                        }`}
                      >
                        <Icon className="w-5 h-5 mb-1 text-[#F2C12E]" />
                        <p className="text-xs font-black uppercase">{item.label}</p>
                        <p className="text-[10px] text-neutral-400 font-medium">{item.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Number Input */}
              <div>
                <label className="block text-[11px] font-extrabold uppercase text-amber-200/80 mb-1">
                  2. Enter 11-Digit {kycType} Number
                </label>
                <div className="relative flex items-center">
                  <input 
                    type="text" 
                    placeholder={kycType === 'NIN' ? '12345678901' : kycType === 'BVN' ? '22345678901' : 'UNILAG/2023/84920'} 
                    value={kycNumber}
                    onChange={(e) => setKycNumber(e.target.value.replace(/[^a-zA-Z0-9/]/g, ''))}
                    required
                    className="w-full pl-4 pr-10 py-3 bg-[#24140F] border border-white/10 focus:border-[#F2C12E] rounded-2xl text-xs font-mono outline-none text-white placeholder-neutral-500"
                  />
                  <Lock className="absolute right-3.5 w-4 h-4 text-neutral-500" />
                </div>
              </div>

              {/* Document Photo Upload */}
              <div>
                <label className="block text-[11px] font-extrabold uppercase text-amber-200/80 mb-1">
                  3. Upload Photo of {kycType} Document (Optional / Recommended)
                </label>
                <label className="flex items-center justify-between p-3.5 bg-[#24140F] border border-dashed border-white/20 hover:border-[#F2C12E] rounded-2xl cursor-pointer transition-all">
                  <div className="flex items-center gap-3">
                    <Upload className="w-5 h-5 text-[#F2C12E]" />
                    <span className="text-xs text-neutral-300 font-medium">
                      {documentFile ? '✓ Document Photo Attached' : `Select image of your ${kycType} card or slip`}
                    </span>
                  </div>
                  <input type="file" onChange={handleDocumentUpload} accept="image/*" className="hidden" />
                </label>
              </div>

              {/* 10 Security Features */}
              <div className="p-4 bg-[#24140F] border border-amber-500/20 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-black text-[#F2C12E] uppercase tracking-wide">Didit 10 Security Verification Features:</p>
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                    Didit.me Free Engine
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-300">
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 1. Didit Document OCR Scan</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 2. Didit 3D Facial Liveness</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 3. NIMC/BVN Match Protocol</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 4. Anti-Spoof Photo Audit</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 5. Encrypted Crime Tracking</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 6. Tobjosh Escrow Lock</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 7. In-App Safe Messaging Audit</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 8. Official Blue Check Badge</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 9. Real-Time ETA Broadcast</div>
                  <div className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" /> 10. Fraud Suspicion Auto-Freeze</div>
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-3.5 bg-[#F2C12E] hover:bg-[#e0b025] text-[#180E09] font-black uppercase tracking-wider rounded-2xl transition-all shadow-lg text-xs"
              >
                Proceed to Biometric Liveness Check
              </button>
            </form>
          )}

          {step === 'camera' && (
            <div className="text-center space-y-5 py-4">
              <div className="relative w-48 h-48 mx-auto rounded-full border-4 border-dashed border-[#F2C12E] p-2 flex items-center justify-center bg-[#24140F] overflow-hidden">
                {cameraActive ? (
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="w-full h-full object-cover rounded-full"
                  />
                ) : isVerifying ? (
                  <div className="flex flex-col items-center gap-2">
                    <Loader2 className="w-8 h-8 text-[#F2C12E] animate-spin" />
                    <span className="text-[10px] font-bold uppercase text-[#F2C12E]">Matching Facial Biometrics...</span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Camera className="w-10 h-10 text-[#F2C12E]" />
                    <span className="text-[10px] font-bold uppercase text-neutral-300">Face Verification Active</span>
                  </div>
                )}
                <div className="absolute inset-0 bg-emerald-500/10 animate-pulse pointer-events-none" />
              </div>

              <div>
                <h4 className="text-base font-black text-white">Biometric Face Matching</h4>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto mt-1">
                  Look directly into the camera to match your {kycType} record against NIMC/BVN registry.
                </p>
              </div>

              <button 
                type="button"
                onClick={handleSimulateFacialScan}
                disabled={isVerifying}
                className="w-full py-3.5 bg-[#F2C12E] hover:bg-[#e0b025] text-[#180E09] font-black uppercase tracking-wider rounded-2xl transition-all shadow-lg text-xs disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isVerifying ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#180E09]" />
                    <span>Verifying {kycType} Records...</span>
                  </>
                ) : (
                  <>
                    <Eye className="w-4 h-4" />
                    <span>Capture & Verify Face Now</span>
                  </>
                )}
              </button>
            </div>
          )}

          {step === 'done' && (
            <div className="text-center space-y-5 py-6">
              <div className="w-16 h-16 bg-emerald-500/20 border-2 border-emerald-500 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-xl font-black text-white uppercase tracking-tight">KYC Identity Verified!</h4>
                <p className="text-xs text-neutral-300 mt-1 max-w-sm mx-auto">
                  Your {kycType} record ({kycNumber.slice(0, 4)}••••{kycNumber.slice(-2)}) is authenticated. Your account now carries the official verified blue check badge.
                </p>
              </div>

              <button 
                type="button"
                onClick={onClose}
                className="w-full py-3.5 bg-[#F2C12E] hover:bg-[#e0b025] text-[#180E09] font-black uppercase tracking-wider rounded-2xl transition-all shadow-lg text-xs"
              >
                Done • Unlock Full Access
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
