/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { MapPin, Search, Navigation, Compass, Layers, Globe } from 'lucide-react';
import { Job } from '../types';

interface MapSimulationProps {
  jobs: Job[];
  selectedLocation: {
    country: string;
    state: string;
    city: string;
  };
  onSelectJob?: (job: Job) => void;
}

// Map coordinates for major cities to show correct marker placement on our visual world grid
const CITY_COORDINATES: Record<string, { x: number; y: number }> = {
  "Los Angeles": { x: 18, y: 40 },
  "San Francisco": { x: 16, y: 36 },
  "San Diego": { x: 19, y: 42 },
  "New York City": { x: 28, y: 35 },
  "Houston": { x: 22, y: 46 },
  "Austin": { x: 21, y: 48 },
  "Miami": { x: 27, y: 49 },
  "London": { x: 48, y: 25 },
  "Manchester": { x: 47, y: 23 },
  "Edinburgh": { x: 47, y: 20 },
  "Toronto": { x: 26, y: 32 },
  "Ottawa": { x: 28, y: 30 },
  "Vancouver": { x: 15, y: 28 },
  "Berlin": { x: 53, y: 24 },
  "Munich": { x: 52, y: 27 },
  "Cologne": { x: 51, y: 25 },
  "Lagos City": { x: 49, y: 62 },
  "Victoria Island": { x: 50, y: 63 },
  "Lekki": { x: 51, y: 63 },
  "Maitama": { x: 52, y: 60 },
  "Ibadan": { x: 48, y: 61 },
  "Port Harcourt": { x: 50, y: 65 }
};

export default function MapSimulation({ jobs, selectedLocation, onSelectJob }: MapSimulationProps) {
  const [activePin, setActivePin] = useState<Job | null>(null);
  const [satelliteView, setSatelliteView] = useState(false);
  const [mapScale, setMapScale] = useState(1);
  const [mapCenter, setMapCenter] = useState({ x: 50, y: 50 }); // percentage

  // When selected location changes, pan map to that location's coordinates
  useEffect(() => {
    if (selectedLocation.city && CITY_COORDINATES[selectedLocation.city]) {
      const coords = CITY_COORDINATES[selectedLocation.city];
      setMapCenter(coords);
      setMapScale(2.2); // Zoom in on location
    } else if (selectedLocation.country) {
      // Find first city in that country
      const firstCityInCountry = jobs.find(j => j.location.country === selectedLocation.country)?.location.city;
      if (firstCityInCountry && CITY_COORDINATES[firstCityInCountry]) {
        setMapCenter(CITY_COORDINATES[firstCityInCountry]);
        setMapScale(1.6);
      } else {
        setMapCenter({ x: 50, y: 50 });
        setMapScale(1);
      }
    } else {
      setMapCenter({ x: 50, y: 50 });
      setMapScale(1);
    }
    setActivePin(null);
  }, [selectedLocation, jobs]);

  const handleReset = () => {
    setMapCenter({ x: 50, y: 50 });
    setMapScale(1);
    setActivePin(null);
  };

  return (
    <div className="relative w-full h-[400px] bg-[#160d09] rounded-2xl overflow-hidden border border-[#D4AF37]/30 shadow-2xl group flex flex-col justify-between" id="google-maps-simulation">
      {/* Map Header with coordinates */}
      <div className="absolute top-4 left-4 right-4 z-10 flex items-center justify-between pointer-events-none">
        <div className="bg-[#1C100B]/90 border border-[#D4AF37]/40 px-3 py-1.5 rounded-lg flex items-center gap-2 text-[10px] font-mono text-[#D4AF37] pointer-events-auto backdrop-blur-sm shadow-lg">
          <Compass className="w-3.5 h-3.5 animate-spin-slow text-[#D4AF37]" />
          <span>LAT: {(40.7128 + (mapCenter.y - 50) * -1.2).toFixed(4)}° N</span>
          <span className="text-[#D4AF37]/40">|</span>
          <span>LNG: {(-74.0060 + (mapCenter.x - 50) * 2.4).toFixed(4)}° W</span>
        </div>

        <div className="flex gap-2 pointer-events-auto">
          <button
            onClick={() => setSatelliteView(!satelliteView)}
            className={`p-1.5 rounded-lg border text-xs font-medium transition-all duration-200 backdrop-blur-sm ${
              satelliteView
                ? 'bg-[#D4AF37] text-[#1C100B] border-[#D4AF37]'
                : 'bg-[#1C100B]/80 text-[#D4AF37] border-[#D4AF37]/30 hover:border-[#D4AF37]/60'
            }`}
            title="Toggle Map Layers"
          >
            <Layers className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleReset}
            className="p-1.5 rounded-lg border bg-[#1C100B]/80 text-[#D4AF37] border-[#D4AF37]/30 hover:border-[#D4AF37]/60 text-xs font-medium transition-all duration-200 backdrop-blur-sm"
            title="Recenter World Map"
          >
            <Globe className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Map Grid and Layout */}
      <div className="relative w-full h-full overflow-hidden flex items-center justify-center">
        {/* Background Grid Layer */}
        <div 
          className="absolute inset-0 transition-transform duration-700 ease-out"
          style={{
            transform: `scale(${mapScale}) translate(${(50 - mapCenter.x) * 0.5}%, ${(50 - mapCenter.y) * 0.5}%)`,
            backgroundImage: satelliteView 
              ? 'radial-gradient(circle, #2d1e15 10%, #160d09 90%)' 
              : 'linear-gradient(to right, rgba(212,175,55,0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(212,175,55,0.03) 1px, transparent 1px)',
            backgroundSize: '40px 40px',
          }}
        >
          {/* Abstract continents styled in luxurious darken gold */}
          <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
            {/* North America */}
            <path d="M5,10 Q12,20 25,25 Q35,18 30,35 Q22,40 18,30 Z" fill="#D4AF37" />
            {/* South America */}
            <path d="M18,45 Q26,55 22,80 Q15,75 14,55 Z" fill="#D4AF37" />
            {/* Eurasia / Europe */}
            <path d="M42,10 Q50,5 65,15 Q80,10 88,25 Q70,35 60,25 Z" fill="#D4AF37" />
            {/* Africa */}
            <path d="M42,32 Q58,35 55,60 Q48,78 45,65 Q38,50 42,32 Z" fill="#D4AF37" />
            {/* Australia */}
            <path d="M75,65 Q85,68 80,82 Q70,80 75,65 Z" fill="#D4AF37" />
          </svg>

          {/* Golden scanning ring when zoom changes */}
          <div className="absolute inset-0 border border-[#D4AF37]/5 rounded-full animate-ping pointer-events-none" style={{ margin: 'auto', width: '300px', height: '300px' }} />

          {/* Dynamic pins for available Gigs and Errands */}
          {jobs.map((job) => {
            const coords = CITY_COORDINATES[job.location.city] || { x: 35 + (Math.random() * 30), y: 35 + (Math.random() * 30) };
            const isActive = activePin?.id === job.id;
            const isSelectedCity = selectedLocation.city === job.location.city;

            return (
              <div
                key={job.id}
                className="absolute transition-all duration-500 ease-in-out cursor-pointer group/pin"
                style={{
                  left: `${coords.x}%`,
                  top: `${coords.y}%`,
                  transform: `translate(-50%, -50%) scale(${isActive ? 1.3 : 1})`,
                }}
                onClick={() => setActivePin(isActive ? null : job)}
              >
                {/* Glowing ring under the marker */}
                <div className={`absolute -inset-2 rounded-full blur-sm transition-all duration-300 ${
                  job.type === 'gig' 
                    ? 'bg-[#D4AF37]/30 group-hover/pin:bg-[#D4AF37]/50' 
                    : 'bg-amber-500/20 group-hover/pin:bg-amber-500/40'
                } ${isSelectedCity ? 'animate-ping duration-1000' : ''}`} />

                {/* Pin Icon */}
                <div className={`relative p-1.5 rounded-full border transition-all duration-300 shadow-lg ${
                  isActive 
                    ? 'bg-[#D4AF37] text-[#1C100B] border-[#D4AF37]' 
                    : job.type === 'gig'
                      ? 'bg-[#1C100B] text-[#D4AF37] border-[#D4AF37]/60 group-hover/pin:border-[#D4AF37]'
                      : 'bg-[#1C100B] text-amber-500 border-amber-500/60 group-hover/pin:border-amber-500'
                }`}>
                  <MapPin className="w-3.5 h-3.5" />
                </div>

                {/* Mini Tooltip */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1.5 hidden group-hover/pin:block bg-[#1C100B] border border-[#D4AF37]/30 px-2 py-0.5 rounded text-[9px] text-[#D4AF37] font-mono whitespace-nowrap z-30 shadow-md">
                  {job.title} (${job.budget})
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Popup for Selected Pin */}
      {activePin && (
        <div className="absolute bottom-4 left-4 right-4 bg-[#1C100B]/95 border border-[#D4AF37]/50 p-4 rounded-xl shadow-2xl backdrop-blur-md animate-in fade-in slide-in-from-bottom-2 z-20">
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-mono uppercase font-semibold mb-1.5 ${
                activePin.type === 'gig' 
                  ? 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20' 
                  : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'
              }`}>
                {activePin.type === 'gig' ? '🎵 Musical Gig' : '💻 Online Errand'} • {activePin.category}
              </span>
              <h4 className="font-bold text-sm text-amber-100 mb-1">{activePin.title}</h4>
              <p className="text-[11px] text-amber-200/70 flex items-center gap-1 font-mono">
                <MapPin className="w-3 h-3 text-[#D4AF37]" />
                {activePin.location.city}, {activePin.location.state}, {activePin.location.country}
              </p>
            </div>
            <div className="text-right">
              <span className="block text-xs text-amber-200/50 font-mono">Escrow Budget</span>
              <span className="text-lg font-mono font-bold text-[#D4AF37]">${activePin.budget}</span>
              {onSelectJob && (
                <button
                  onClick={() => onSelectJob(activePin)}
                  className="mt-2 block w-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-[#D4AF37] text-[#1C100B] rounded hover:bg-[#b8952d] transition-all duration-200"
                >
                  View Details
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Status Indicator */}
      <div className="absolute bottom-3 left-4 text-[10px] font-mono text-[#D4AF37]/40 pointer-events-none flex items-center gap-1.5">
        <div className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
        <span>GIGS ACTIVE IN CLOUD DIRECTORY</span>
      </div>
    </div>
  );
}
