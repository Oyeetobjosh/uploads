# Tobjosh Ultimates & Gigs Ecosystem

An end-to-end Nigerian Gig Marketplace, Campus Service Network, and Escrow Financial Hub built with **React, TypeScript, Express, Tailwind CSS, Firebase Firestore**, and **Paystack Gateway Integration**.

---

## 📌 Executive Architecture Summary (For AI Agents & Developers)

| Layer | Technology / Implementation |
| :--- | :--- |
| **Frontend Framework** | React 18 + Vite (TypeScript, `motion` animations, Lucide icons, Tailwind CSS) |
| **Backend Framework** | Express v4 custom server (`server.ts`) running on port `3000` |
| **Database & Auth** | Firebase Firestore + Firebase Authentication (`ai-studio-tobjoshultimates-c5ffe428-e2ff-42b8-95c4-8b3f6d3ffe25`) + local fallback persistence |
| **Payment Gateway** | Paystack Fintech API (`/api/paystack/*` proxy endpoints) |
| **Identity Verification** | NIN / BVN / Student ID instant verification with facial biometric matching |
| **Build System** | `tsx server.ts` (Dev Mode) / `esbuild` bundled CJS server outputting to `dist/server.cjs` (Production Mode) |

---

## 🚀 Key Architectural Modules

### 1. Paystack Payment Gateway (`/api/paystack/*`)
Located in `server.ts` and `src/components/PaystackCheckoutModal.tsx`.
* **Security Rule**: API keys (`PAYSTACK_SECRET_KEY`) are kept **strictly server-side** inside `server.ts` and proxied via `/api/paystack/*` routes.
* **Supported Payment Channels**:
  * 💳 **Debit / Credit Card** (Mastercard, Visa, Verve)
  * 🏦 **Instant Virtual Bank Transfer** (Wema / Paystack virtual account generator)
  * 📱 **USSD Quick Codes** (*737#, *901#, *919#)
  * 🎓 **Free Student Startup Gateway**: 0% processing fee waiver for verified campus creators and student startups.
* **Endpoints**:
  * `GET /api/paystack/status` – Gateway health and key validation.
  * `POST /api/paystack/initialize` – Converts Naira to Kobo and creates Paystack checkout session.
  * `GET /api/paystack/verify/:reference` – Verifies transaction status.
  * `GET /api/paystack/banks` – Retrieves list of NUBAN-supported Nigerian banks (Access, GTB, Zenith, Kuda, OPay, Palmpay, Moniepoint, etc.).
  * `POST /api/paystack/resolve-account` – Resolves 10-digit NUBAN account numbers to bank account holder names.
  * `POST /api/paystack/transfer` – Automated withdrawal/payout to provider bank accounts.
  * `POST /api/paystack/webhook` – Asynchronous Paystack event listener.

### 2. Free KYC & Identity Verification
Located in `src/components/KycVerificationModal.tsx`.
* Instant identity matching against NIMC (NIN) and CBN (BVN) registry protocols.
* Biometric facial scanning simulation.
* Grants a **Blue Verified Checkmark Badge** (`✓ Verified`) across user profiles, gig cards, and service listings to establish high-trust transactions.

### 3. Escrow & Marketplace Engine
Located in `src/App.tsx`, `src/types.ts`, and `src/components/HomeRenovation.tsx`.
* **Gig & Errand Posting**: Allows buyers to hire skilled talent (pianists, caterers, sound engineers, tutors, campus errands).
* **Escrow Lock & Release**: Funds are safely held in escrow (`escrowBalance`) upon hiring and only released to the provider's wallet balance (`balance`) when milestones or gig deliverables are marked completed.
* **Ratings & Reviews**: Completed gig metrics and star ratings for providers.

---

## 🛠️ Environment Variables Configuration

Refer to `.env.example` for required environment variables:

```env
# Server Ingress Port (Fixed by Cloud Run container architecture)
PORT=3000

# Firebase Database
FIREBASE_PROJECT_ID="ai-studio-tobjoshultimates-c5ffe428-e2ff-42b8-95c4-8b3f6d3ffe25"

# Paystack API Keys (Set in environment variables or AI Studio Secrets)
PAYSTACK_SECRET_KEY="sk_test_..."
VITE_PAYSTACK_PUBLIC_KEY="pk_test_..."

# Self-referential App URL
APP_URL="https://ais-dev-etvk3cawyptp3ocwsj3dji-3123104237.europe-west1.run.app"
```

---

## 📂 Project Directory Structure

```
.
├── server.ts                       # Express backend & Paystack proxy API endpoints
├── src/
│   ├── App.tsx                     # Main application logic, escrow engine & state
│   ├── types.ts                    # Global TypeScript interfaces (User, Job, Transaction, KYC)
│   ├── components/
│   │   ├── PaystackCheckoutModal.tsx # Paystack payment gateway modal UI
│   │   ├── KycVerificationModal.tsx  # Free NIN/BVN biometric identity verification UI
│   │   ├── HomeRenovation.tsx       # Main service marketplace dashboard & Wallet UI
│   │   ├── MapSimulation.tsx        # Interactive service provider location map
│   │   ├── TobjoshLogo.tsx          # Brand SVG logo
│   │   └── BusyBackground.tsx       # Animated background canvas
├── metadata.json                   # Applet permissions & capabilities
├── package.json                    # Scripts and dependencies (dev: "tsx server.ts")
└── .env.example                    # Environment key declarations
```

---

## ⚡ Build & Execution Commands

* **Development Server**: `npm run dev` (Runs `tsx server.ts` on port `3000`)
* **Type Checking & Linting**: `npm run lint` (`tsc --noEmit`)
* **Production Build**: `npm run build` (Compiles Vite client assets and bundles `server.ts` to `dist/server.cjs` via `esbuild`)
* **Production Start**: `npm run start` (`node dist/server.cjs`)

---

## 🤖 Instructions for AI Agents Continuing Development

1. **Security**: Never expose `PAYSTACK_SECRET_KEY` in client-side components. Always route Paystack calls through `/api/paystack/*` in `server.ts`.
2. **Port Restriction**: The server **must** listen on `0.0.0.0:3000`. Do not modify the port number.
3. **Escrow Invariance**: Ensure `escrowBalance` and `balance` calculations remain synchronized during milestone creation, escrow holds, and job completion releases.
4. **Student Startup Perks**: Keep the `isStudentStartup` 0% fee waiver logic active for campus users.
